"""Verify the directly delivered change after swept-direction confirmation."""

from collections import Counter
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
done = read_json(root / "output/collection.json")
plan = read_json(checked(done["plan"]))
report = read_json(root / "review/result.json")
inherited = read_json(checked(plan["retained"]))
fresh = read_json(checked(plan["fresh"]))
fresh_plan = read_json(checked(plan["fresh_plan"]))
ROI = np.s_[..., 128:384, 128:384]


def direct(case, values, alpha, fresh_case=False):
    if fresh_case:
        with np.load(checked(case["parent"])) as f:
            parent = f["parent"].astype(np.float64)
    else:
        parent = np.load(checked(case["parent"])).astype(np.float64)
    with np.load(checked(case["target"])) as f:
        gt, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
    prediction = parent.copy()
    prediction[ROI] += (values.astype(np.float64) - parent[ROI]) * alpha
    weak = gt[2] - gt[1]
    predicted = prediction[2] - prediction[1]
    return np.asarray(
        [
            np.vdot(predicted, weak) / np.vdot(weak, weak),
            np.mean(((predicted - weak) * 65535) ** 2),
            np.mean(((prediction - gt)[ROI][..., quiet] * 65535) ** 2),
        ]
    )


counts = {"retained": Counter(), "fresh": Counter()}
rows = {"retained": [], "fresh": []}
for key, incoming, prior in (
    ("retained", done["synthetic"], inherited["synthetic"]),
    ("fresh", done["fresh"], [read_json(checked(ref)) for ref in fresh["cases"]]),
):
    for new, old in zip(incoming, prior, strict=True):
        assert new["id"] == old["id"]
        case = new if key == "fresh" else read_json(checked(new["case"]))
        for a, b in zip(new["rankings"], old["rankings"], strict=True):
            assert a["fits"]["scene"] == b["fits"]["scene"]
            before, after = a["fits"]["scene"], a["fits"]["curved"]
            assert before.get("donor_boxes") == after.get("donor_boxes")
            counts[key]["confirmed"] += after["curved_direction_added"]
            if after["curved_direction_added"]:
                assert before["frequencies_xy"][0] == after["frequencies_xy"][0]
                assert after["curved_direction_check"]["accepted"][1]
        with np.load(checked(new["prediction"])) as f, np.load(checked(old["prediction"])) as g:
            for name in f.files:
                if not name.startswith("curved"):
                    np.testing.assert_array_equal(f[name], g[name])
                    continue
                bname = name.replace("curved", "scene")
                delta = (f[name].astype(np.float64) - f[bname]) * 65535
                changes = [float(np.sqrt(np.mean(d**2))) for d in delta]
                counts[key]["changed_arrays"] += any(changes)
                record = {"id": new["id"], "key": name, "changes_DN16_by_role": changes}
                if key == "fresh" and any(changes):
                    scale = fresh_plan["settings"][case["profile"]]["scale"]
                    record["fixed_scene_and_curved_weak_gain_mse_and_quiet_mse"] = [
                        direct(case, f[n], scale, True).tolist() for n in (bname, name)
                    ]
                rows[key].append(record)

measurements = []
for aggregate in report["aggregates"]:
    cond = aggregate["setting"]
    if aggregate["kind"] not in ("all", "curved") or cond["budget_DN16"] != 0.02:
        continue
    variants = []
    for arm in ("scene", "curved"):
        group = []
        for row in done["synthetic"]:
            c = read_json(checked(row["case"]))
            if (c["profile"], c["placement"]) != (cond["profile"], cond["placement"]) or aggregate[
                "kind"
            ] not in ("all", c["kind"]):
                continue
            with np.load(checked(row["prediction"])) as f:
                group.append(
                    direct(
                        c, f[f"{arm}--t{cond['threshold']:g}"], aggregate["matched"][arm]["scale"]
                    )
                )
        result = np.mean(group, axis=0)
        result[1:] **= 0.5
        expected = [
            aggregate["matched"][arm][name]
            for name in ("weak_gain", "weak_increment_RMS_DN16", "quiet_RMS_DN16")
        ]
        np.testing.assert_allclose(result, expected, rtol=1e-10, atol=1e-10)
        variants.append(result.tolist())
    measurements.append(
        {
            "profile": cond["profile"],
            "placement": cond["placement"],
            "kind": aggregate["kind"],
            "scene_then_curved": variants,
        }
    )

for a, b in zip(done["camera"], inherited["camera"], strict=True):
    assert a["id"] == b["id"] and a["prediction"] == b["prediction"]
    assert not a["fit"]["curved_direction_added"]
write_json(
    root / "review/audit.json",
    {
        "producer": reference(__file__),
        "collection": reference(root / "output/collection.json"),
        "counts": counts,
        "retained_equal_quiet": measurements,
        "per_array": rows,
        "camera_exact": 8,
    },
)
