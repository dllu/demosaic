"""Bind the native panels and independently checked curvature replay."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
results = Path("docs/results") / root.name
images = Path("docs/images") / root.name
images.mkdir()
report = read_json(root / "review/result.json")
plan = read_json(checked(report["plan"]))
audit = read_json(root / "review/audit.json")
assert audit["camera_exact"] == 8
boards = []
for r in report["boards"]:
    case = read_json(checked(r["case_receipt"]))
    outputs = []
    for key in ("board", "triplet"):
        image = checked(r[key]["image"])
        copy = images / image.name
        shutil.copyfile(image, copy)
        assert reference(copy)["sha256"] == r[key]["image"]["sha256"]
        outputs.append(r[key] | {"file": image.name})
    boards.append(
        {k: v for k, v in r.items() if k not in ("board", "triplet")}
        | {
            "CFA": case["CFA"],
            "noise": case["metadata"]["noise"],
            "checkpoint": plan["parent_checkpoint"],
            "images": outputs,
        }
    )
manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "synthetic": boards,
        "byte_identical_camera_outputs": audit["camera_exact"],
        "camera_native_viewing": reference("docs/images/affinity-first-donors-v1/manifest.json"),
    },
)
shutil.copyfile(root / "review/audit.json", results / "independent-audit.json")
names = [
    "plan.json",
    "collect.log",
    "output/collection.json",
    "review/result.json",
    "review/audit.json",
    "audit.py",
    "publish.py",
    "work/src/demosaic/search_donor_geometry.py",
    "work/scripts/probe_curved_donor_rescue.py",
]
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as output,
    gzip.GzipFile(filename="", fileobj=output, mode="wb", mtime=0) as compressed,
    tarfile.open(fileobj=compressed, mode="w") as tar,
):
    for name in names:
        file = root / name
        meta = tar.gettarinfo(str(file), arcname=f"{root.name}/{name}")
        meta.uid = meta.gid = meta.mtime = 0
        meta.uname = meta.gname = ""
        with file.open("rb") as stream:
            tar.addfile(meta, stream)
with tarfile.open(archive) as tar:
    for name in names:
        assert tar.extractfile(f"{root.name}/{name}").read() == (root / name).read_bytes()
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "members_verified": len(names),
        "audit": reference(results / "independent-audit.json"),
        "native_manifest": reference(manifest),
        "actual_native_triplets_and_boards": 2,
        "camera_exact_matches_to_appearance_first": 8,
        "new_neural_forwards": 0,
    },
)
