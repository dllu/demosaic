"""Render all standing views and two exact-target comparisons at native size."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import CONTEXT, PARENTS, ROOT, arrays, target_coeff
from report_scene_wave_guides import native_board
import spectrum,coherent,parent_phase
from matched import POLICY

sys.path.insert(0,str(ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png


def exact(output):
    receipt=reference(ROOT/'parent-phase-results.json')
    notes=read_json(checked(receipt))
    assert len(notes['rows'])==256
    cohort=read_json(checked(reference(CONTEXT)))
    parents={r['id']:r for r in read_json(checked(reference(PARENTS)))['records']}
    items=[r for r in notes['rows'] if r['noise']=='iso6400' and r['draw']=='independent' and r['case']>=32]
    strength=notes['summary']['iso6400']['quiet_calibrated_strength'][POLICY]
    def change(r):
        c=np.asarray(r['scores'][POLICY]['increment'])
        return float(np.sqrt(c @ np.array([1.,strength,strength**2]))-np.sqrt(c[0]))
    extremes=[min(items,key=change),max(items,key=change)]
    boards=[]
    for row in extremes:
        case,input_,baseline=arrays(parents[row['id']])
        source=cohort['rows'][case['case']]
        calibration={k:input_[k][None]for k in ('colors','wb','matrix')}
        layout,wb,matrix=(input_[k] for k in ('colors','wb','matrix'))
        physical=case['profile']
        surroundings=spectrum.exterior(input_['scene_packed'],layout,physical,case['box'])
        role=0
        choices=[]
        for stage in (spectrum,coherent,parent_phase):
            selected,_=stage.compose(input_['packed'][role],layout,physical,case['box'],surroundings,baseline[role],wb,matrix)
            # Display the fixed output of each rule. The paired numeric comparison also matches quiet input scale.
            choices.append(selected[POLICY])
        for role, name in ((0,'present'),(2,'flat')):
            if role==2:
                choices=[]
                for stage in (spectrum,coherent,parent_phase):
                    selected,_=stage.compose(input_['packed'][role],layout,physical,case['box'],surroundings,baseline[role],wb,matrix)
                    choices.append(selected[POLICY])
            noisy=noisy_malvar(calibration|{'packed':input_['packed'][role:role+1]})[0]
            pieces=(noisy,baseline[role],*choices,input_['target'][role])
            labels=('Noisy Malvar','Corpus 100k','RAW mean lift','Cross-power bound','Parent phase','Exact GT')
            board=native_board(output,f"{row['id']}-{name}",pieces,calibration,
                 {'case':row['input'],'source':source['source'],'geometry':case['box'],'noise':physical,
                  'CFA':source['camera']['pattern'],'role':name,'paired_gated_change_DN16':change(row)},
                 labels=labels,triplet_indices=(0,4,5),exposure=1/physical['exposure'],contrast=2,
                 roi=tuple(cohort['native_display_ROI_xywh']))
            boards.append(board)
    return {'source':receipt,'rows':boards}


def camera(output):
    bindings=[reference(ROOT/label/'manifest.json')for label in ('standing','standing-coherent','standing-parent-phase')]
    collected=[read_json(checked(i))for i in bindings]
    base=read_json(checked(collected[0]['previous']))
    picked=[]
    for row,old,*rest in zip(collected[0]['rows'],base['rows'],collected[1]['rows'],collected[2]['rows'],strict=True):
        assert all(m['id']==old['id'] for m in (row,*rest))
        with Image.open(checked(old['image'])) as f:
            raster=np.asarray(f.convert('RGB'))
        earlier={p['name']:raster[y:y+h,x:x+w]for p in old['panels']for x,y,w,h in (p['png_xywh'],)}
        with np.load(checked(old['base_input']),allow_pickle=False) as f:
            cal={k:f[k][:1]for k in ('wb','matrix')}
        x,y,w,h=old['ROI']
        origin_x,origin_y=old['box'][:2]
        view=np.s_[...,y-origin_y:y-origin_y+h,x-origin_x:x-origin_x+w]
        keep=[(k,earlier[k])for k in ('ISO6400 camera JPEG','Noisy (Malvar)','Parent 100k EMA','Exterior-frequency colour')if k in earlier]
        for proof,label in zip((row,*rest),('RAW mean lift','Cross-power bound','Parent phase'),strict=True):
            with np.load(checked(proof['npz']),allow_pickle=False) as f:
                estimate=f[POLICY][None][view]
            pixels=np.rint(display(estimate,cal,exposure=old['display_exposure'])[0].transpose(1,2,0)*255).astype(np.uint8)
            keep.append((label,pixels))
        keep.extend((k,earlier[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in earlier)
        board=native_png(output/(old['id']+'.png'),keep)
        picked.append({'id':old['id'],'source':row['raw_source'],'query_xywh':row['query_xywh'],'ROI_raw_xywh':row['ROI_raw_xywh'],
          'exposure':row['display_exposure'],'noise':row['noise'],
          'results':{mode:q['comparisons'][POLICY]for mode,q in zip(('raw-mean','cross-power','parent-phase'),(row,*rest),strict=True)},
          'board':board})
    assert len(picked)==8
    return {'sources':bindings,'rows':picked,'checkpoint':base['checkpoint']}


def main():
    torch.set_num_threads(2)
    output=ROOT/'native'
    output.mkdir()
    write_json(output/'manifest.json',{'driver':reference(__file__),'exact':exact(output),'standing':camera(output)})

if __name__=='__main__':
    main()
