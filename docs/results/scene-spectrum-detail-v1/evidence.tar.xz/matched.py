"""Compare the three delivery rules at the same calibration response."""
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import ROOT

DRIVERS={'raw-mean':'results.json','cross-power':'coherent-results.json','parent-phase':'parent-phase-results.json'}
POLICY='exterior-shaped'


def main():
    bindings={key:reference(ROOT/path) for key,path in DRIVERS.items()}
    data={key:read_json(checked(binding)) for key,binding in bindings.items()}
    records={key:{r['id']:r for r in source['rows']} for key,source in data.items()}
    order=tuple(records['raw-mean'])
    assert all(tuple(source)==order for source in records.values())
    rng=np.random.default_rng(239551)
    report={}
    for noise in ('iso400','iso6400'):
        fitted=[key for key in order if records['raw-mean'][key]['noise']==noise
                and records['raw-mean'][key]['case']<32 and records['raw-mean'][key]['draw']=='coupled']
        gain={key:sum(source[r]['scores'][POLICY]['delta_dot'] for r in fitted) for key,source in records.items()}
        assert min(gain.values())>0
        scales={key:float(min(gain.values())/v) for key,v in gain.items()}
        report[noise]={'strength':scales}
        for law in ('coupled','independent'):
            chosen=[key for key in order if records['raw-mean'][key]['noise']==noise
                    and records['raw-mean'][key]['case']>=32 and records['raw-mean'][key]['draw']==law]
            bootstrap=rng.integers(len(chosen),size=(4000,len(chosen)))
            groups={'parent':(records['raw-mean'],'parent',1.)}
            groups.update({key:(source,POLICY,scales[key])for key,source in records.items()})
            stats={}
            for label,(source,policy,amount) in groups.items():
                vals=[source[r]['scores'][policy]for r in chosen]
                entry={}
                for measure in ('increment','present','flat','flat_added','absent_added'):
                    score=np.array([v[measure]for v in vals])
                    old=np.sqrt(score[:,0].clip(min=0))
                    new=np.sqrt((score @ np.array([1.,amount,amount**2])).clip(min=0))
                    delta=new-old
                    entry[measure]={'mean':float(new.mean()),'change_vs_parent':[float(delta.mean()),
                           *np.quantile(delta[bootstrap].mean(axis=1),[.025,.975]).tolist()]}
                gain=np.array([v['dot']+amount*v['delta_dot']for v in vals])
                denom=np.array([v['target']for v in vals])
                entry['response']=float(100*gain.sum()/denom.sum())
                stats[label]=entry
            report[noise][law]=stats
    write_json(ROOT/'response-matched.json',{'driver':reference(__file__),'inputs':bindings,
               'experiments':report,'scope':'Fit one scalar to the same added response using 32 development coupled photos. Measure both noise laws on the remaining 32 photos.'})


if __name__=='__main__':
    main()
