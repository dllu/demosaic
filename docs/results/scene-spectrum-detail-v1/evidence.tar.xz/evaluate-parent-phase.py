"""Compare scene spectral priors on identical exact-detail and flat observations."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
from scipy.fft import dctn

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from spectrum import OUT_MODES, exterior
from parent_phase import compose

ROOT=Path(__file__).resolve().parent
PARENTS=ROOT.parent/'natural-raw-donor-evidence-v1/full-parent.json'
CONTEXT=ROOT.parent/'scene-local-contrast-2400-v1/evaluation-plan.json'
CHECKPOINT='87b96f3c487b9edaf1c477742b6c38f2a82cc6b20a94716d51cc8cf46a17a760'
LUMA=np.array([.2126,.7152,.0722])
DOMAIN=('increment','present','flat','flat_added','absent_added')
FREQ=np.arange(16)/32
FINE=(np.hypot(FREQ[:,None],FREQ[None,:])>=1/8)&(np.hypot(FREQ[:,None],FREQ[None,:])<1/3)
MODES=('parent',*OUT_MODES)


def arrays(record):
    case=read_json(checked(record['source']))
    assert case['id']==record['id']
    with np.load(checked(case['input']),allow_pickle=False) as f:
        fields={k:f[k] for k in ('packed','variance','scene_packed','wb','matrix','colors','target')}
    if record['npz_field'] is None:
        p=np.load(checked(record['rgb']),allow_pickle=False)
    else:
        with np.load(checked(record['rgb']),allow_pickle=False) as f:
            p=f[record['npz_field']]
    assert p.dtype==np.float32 and p.shape==fields['target'].shape==(3,3,256,256)
    assert record['exact_query']=={k:case['fingerprints'][k] for k in record['exact_query']}
    return case,fields,p


def restore(case, fields, parent):
    cfa,wb,matrix=(fields[k] for k in ('colors','wb','matrix'))
    current=exterior(fields['scene_packed'],cfa,case['profile'],case['box'])
    results={mode:[] for mode in OUT_MODES}
    supports=[]
    for raw, image in zip(fields['packed'],parent,strict=True):
        arms, checks=compose(raw,cfa,case['profile'],case['box'],current,image,wb,matrix)
        for mode,value in arms.items():
            results[mode].append(value)
        supports.append(checks)
    return {mode:np.stack(images) for mode,images in results.items()},supports,0 if current is None else len(current.coordinates)


def target_coeff(rgb, calibration, roi):
    x,y,w,h=roi
    assert w==h==96
    scene=linear_rgb(rgb,calibration)
    y=np.einsum('c,bchw->bhw',LUMA,scene)[...,y:y+h,x:x+w]
    blocks=y.reshape(len(y),6,16,6,16).swapaxes(-2,-3).reshape(len(y),36,16,16)
    return dctn(blocks,axes=(-1,-2),norm='ortho')[...,FINE]


def quadratic(reference, difference):
    return (np.array([np.sum(reference**2),2*np.sum(reference*difference),np.sum(difference**2)])
            * (65535**2 / (96**2))).tolist()


def moments(control, option, truth):
    correction=option-control
    error=control-truth
    inc=truth[0]-truth[1]
    estimate=control[0]-control[1]
    lift=correction[0]-correction[1]
    return {'increment':quadratic(estimate-inc,lift),'present':quadratic(error[0],correction[0]),
            'flat':quadratic(error[2],correction[2]),'flat_added':quadratic(np.zeros_like(error[2]),correction[2]),
            'absent_added':quadratic(np.zeros_like(error[1]),correction[1]),
            'dot':float(np.sum(estimate*inc)),'delta_dot':float(np.sum(lift*inc)),
            'target':float(np.sum(inc**2))}


def one(record, spec):
    case, fields, parent=arrays(record)
    candidates,support,donors=restore(case,fields,parent)
    cal={k:np.broadcast_to(fields[k][None],(3,*fields[k].shape)) for k in ('wb','matrix')}
    roi=spec['score_ROI_xywh']
    reference=target_coeff(fields['target'],cal,roi)
    base=target_coeff(parent,cal,roi)
    assert np.max(abs(reference[2]))<1e-14
    scores={'parent':moments(base,base,reference)}
    for mode,img in candidates.items():
        scores[mode]=moments(base,target_coeff(img,cal,roi),reference)
    return {'id':case['id'],'case':case['case'],'source':case['source'],'input':record['source'],
            'noise':case['profile']['name'],'draw':case['draw'],'scores':scores,'support':support,'donors':donors}


def summarize(rows):
    rng=np.random.default_rng(672814)
    combined={}
    for noise in ('iso400','iso6400'):
        fit=[r for r in rows if r['case']<32 and r['draw']=='coupled' and r['noise']==noise]
        assert len(fit)==32
        strengths={k:1. for k in MODES}
        target=min(np.mean([r['scores'][k]['flat_added'][2] for r in fit]) for k in OUT_MODES)
        for k in OUT_MODES:
            level=np.mean([r['scores'][k]['flat_added'][2] for r in fit])
            strengths[k]=min(1.,float(np.sqrt(target/max(level,1e-20))))
        combined[noise]={'quiet_calibrated_strength':strengths}
        for law in ('independent','coupled'):
            selected=[r for r in rows if r['case']>=32 and r['draw']==law and r['noise']==noise]
            sample=rng.integers(0,len(selected),size=(4000,len(selected)))
            table={}
            for condition,scales in (('fixed',{k:1. for k in MODES}),('quiet-matched',strengths)):
                options={}
                for k in MODES:
                    vals=[r['scores'][k] for r in selected]
                    summary={}
                    for metric in DOMAIN:
                        q=np.asarray([v[metric] for v in vals])
                        summary[metric]=np.sqrt(np.maximum(q@np.array([1.,scales[k],scales[k]**2]),0))
                    summary['response']=np.stack(([v['dot']+scales[k]*v['delta_dot'] for v in vals],[v['target']for v in vals]))
                    options[k]=summary
                table[condition]={}
                for k,p in options.items():
                    cell={'means':{z:float(v.mean()) for z,v in p.items() if z!='response'},
                          'aligned_response':float(100*p['response'][0].sum()/p['response'][1].sum()),
                          'comparisons':{}}
                    for other in ('parent','local','exterior-scalar','exterior-transposed'):
                        q=options[other]
                        d={metric:p[metric]-q[metric] for metric in DOMAIN}
                        dot=p['response'][0]-q['response'][0]
                        denom=p['response'][1]
                        cell['comparisons'][other]={m:[float(v.mean()),*np.quantile(v[sample].mean(axis=1),[.025,.975]).tolist()]
                                                     for m,v in d.items()}
                        cell['comparisons'][other]['response']=[float(100*dot.sum()/denom.sum()),
                              *np.quantile(100*dot[sample].sum(1)/denom[sample].sum(1),[.025,.975]).tolist()]
                    table[condition][k]=cell
            combined[noise][law]=table
    return combined


def main():
    prior=reference(PARENTS)
    design=reference(CONTEXT)
    spec=read_json(checked(design))
    saved=read_json(checked(prior))
    records=saved['records']
    assert len(records)==256
    assert read_json(checked(saved['plan']))['model']['sha256']==CHECKPOINT
    rows=[]
    now=time.monotonic()
    with ThreadPoolExecutor(3) as pool:
        for record in pool.map(partial(one,spec=spec),records):
            rows.append(record)
            if len(rows)%16==0:
                print(len(rows),round(time.monotonic()-now,2),flush=True)
    write_json(ROOT/'parent-phase-results.json',{'driver':reference(__file__),'model':reference(ROOT/'parent_phase.py'),'parent':prior,
        'panel':design,'summary':summarize(rows),'rows':rows,'time_seconds':time.monotonic()-now})


if __name__=='__main__':
    main()
