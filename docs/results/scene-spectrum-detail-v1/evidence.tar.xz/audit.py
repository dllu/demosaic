"""Verify native phase, sealed donors and noiseless flat abstention."""
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import reference, write_json
from spectrum import BAND, FX, FY, analyze, compose, exterior

ROOT=Path(__file__).resolve().parent
LAYOUTS=((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0))


def main():
    yy,xx=np.indices((256,256))
    source=(.2+.015*np.cos(2*np.pi*(5*xx+3*yy)/32+.8)).astype(np.float32)
    packed=np.stack([source[p//2::2,p%2::2]for p in range(4)])
    no={'shot':0.,'read':0.}
    nonzero={'shot':.00008,'read':2.56e-8}
    case=[]
    for order in LAYOUTS:
        cfa=np.array(order)
        row=analyze(packed,cfa,nonzero,np.array([48]),np.array([48]))
        selected=(np.isclose(FX,5/32)&np.isclose(FY,3/32))&BAND
        phasors=row.green[0][:,selected].ravel()
        phase_error=abs(np.angle(phasors[0]*phasors[1].conj()))
        assert phase_error<.005,phase_error
        q=(80,80,96,96)
        outer=exterior(packed,cfa,nonzero,q)
        modified=packed.copy()
        replacement=np.random.default_rng(4).uniform(.02,.75,(4,64,64))
        modified[:,32:96,32:96]=replacement
        alternate=exterior(modified,cfa,nonzero,q)
        for f in ('coordinates','features','green','noise','cross'):
            np.testing.assert_array_equal(getattr(outer,f),getattr(alternate,f))
        raw=np.broadcast_to(np.array([.2,.2,.2,.2],dtype=np.float32)[:,None,None],(4,48,48))
        target=np.full((3,96,96),.2,np.float32)
        options,support=compose(raw,cfa,no,q,outer,target,np.ones(3),np.eye(3))
        for key in options:
            np.testing.assert_array_equal(options[key],target)
            assert support[key]['active']==0
        case.append({'cfa':order,'relative_green_phase_error_rad':float(phase_error),'exterior_windows':len(outer.cross)})
    write_json(ROOT/'audit.json',{'driver':reference(__file__),'records':case,'sealed_halo_native_pixels':16,
               'scope':'Four Bayer layouts. A planted sinusoid validates native phase registration. Changing the entire sealed center cannot affect exterior features. Constant noiseless RAW returns all four branches identically.'})

if __name__=='__main__':
    main()
