"""Archive the executed spectral study and reviewed native crops."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import ROOT

OUT=Path('docs/results')/ROOT.name
IMAGES=Path('docs/images')/ROOT.name


def replace(binding,directory):
    source=checked(binding)
    destination=directory/source.name
    shutil.copy2(source,destination)
    published=reference(destination)
    assert published['sha256']==binding['sha256']
    with Image.open(destination)as image:
        assert image.height==192
    return {'path':str(destination),'sha256':published['sha256']}


def main():
    OUT.mkdir()
    IMAGES.mkdir()
    for name in ('exact','standing'):
        (IMAGES/name).mkdir()
    native=read_json(checked(reference(ROOT/'native/manifest.json')))
    for row in native['exact']['rows']:
        row['board']['image']=replace(row['board']['image'],IMAGES/'exact')
        if row['role']=='present':
            row['triplet']['image']=replace(row['triplet']['image'],IMAGES/'exact')
        else:
            del row['triplet']
    for row in native['standing']['rows']:
        row['board']['image']=replace(row['board']['image'],IMAGES/'standing')
    native['actual_native_viewing']={'exact_present_triplets':2,'exact_full_comparisons':4,'standing_camera':8}
    write_json(IMAGES/'manifest.json',native)
    files=('spectrum.py','coherent.py','parent_phase.py','audit.py','audit.json','evaluate.py','evaluate-coherent.py',
           'evaluate-parent-phase.py','standing.py','standing-coherent.py','standing-parent-phase.py','matched.py',
           'results.json','coherent-results.json','parent-phase-results.json','response-matched.json','native.py',
           'standing/manifest.json','standing-coherent/manifest.json','standing-parent-phase/manifest.json',
           'native/manifest.json','publish.py')
    archive=OUT/'evidence.tar.xz'
    digests={}
    with tarfile.open(archive,'x:xz')as stream:
        for file in files:
            path=ROOT/file
            digests[file]=reference(path)['sha256']
            stream.add(path,arcname=file)
    results={}
    for name,file in (('raw-mean','results.json'),('cross-power','coherent-results.json'),('parent-phase','parent-phase-results.json')):
        results[name]=read_json(ROOT/file)['summary']
    write_json(OUT/'publication.json',{'archive':reference(archive),'members':digests,'native':reference(IMAGES/'manifest.json'),
       'checkpoint':native['standing']['checkpoint'],'summaries':results,
       'same_response':read_json(ROOT/'response-matched.json')['experiments'],
       'scope':'No model updates. Exact-target reconstruction and both standing cameras, with no full427 or measured-camera scores.'})


if __name__=='__main__':
    main()
