"""Review scene-selective band lifting on both cached GFX scenes."""
from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image

from demosaic.archive_metrics import display
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from spectrum import OUT_MODES, exterior
from parent_phase import compose
from evaluate import ROOT

BASE=ROOT.parent/'query-exterior-colour-v1/standing/manifest.json'
sys.path.insert(0,str(ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png


def process(row, large, box, origin, cfa, out):
    expected=row['box']
    x,y,w,h=expected
    assert w==h==256
    ix,iy=origin
    actual=(x+ix,y+iy,w,h)
    raw=large[:, actual[1]//2:(actual[1]+h)//2, actual[0]//2:(actual[0]+w)//2]
    with np.load(checked(row['base_input']),allow_pickle=False) as f:
        wb,matrix,colors=(f[k][0] for k in ('wb','matrix','colors'))
        np.testing.assert_array_equal(raw,f['packed'][0,:,y//2:(y+h)//2,x//2:(x+w)//2])
        np.testing.assert_array_equal(cfa,colors)
    with np.load(checked(row['output']),allow_pickle=False) as f:
        before=f['restored']
    from_scene=exterior(large,cfa,row['noise'],actual)
    options,support=compose(raw,cfa,row['noise'],actual,from_scene,before,wb,matrix)
    sx,sy,sw,sh=row['ROI']
    qx,qy=sx-x,sy-y
    rgb_crop=np.s_[...,qy:qy+sh,qx:qx+sw]
    with Image.open(checked(row['image'])) as f:
        strip=np.asarray(f.convert('RGB'))
    existing={p['name']:strip[sy:sy+h,sx:sx+w]for p in row['panels']for sx,sy,w,h in (p['png_xywh'],)}
    panels=[(k,existing[k])for k in ('ISO6400 camera JPEG','Noisy (Malvar)','Parent 100k EMA','Exterior-frequency colour')if k in existing]
    calibration={'wb':wb[None],'matrix':matrix[None]}
    render=lambda v:np.rint(display(v[None],calibration,exposure=row['display_exposure'])[0].transpose(1,2,0)*255).astype(np.uint8)
    summaries={}
    for mode,name in (('local','Local spectral power'),('exterior-scalar','Exterior total power'),
                      ('exterior-shaped','Exterior spectral shape'),('exterior-transposed','Transposed spectrum')):
        rgb=options[mode][rgb_crop]
        pixels=render(rgb)
        base=before[rgb_crop]
        panels.append((name,pixels))
        delta=(rgb.astype(float)-base)*65535
        summaries[mode]=support[mode]|{'camera_RGB_RMS_DN16':float(np.sqrt(np.mean(delta**2))),
                           'camera_RGB_max_DN16':float(abs(delta).max()),
                           'changed_8bit_pixels':int(np.any(pixels!=render(base),axis=-1).sum())}
    panels.extend((k,existing[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in existing)
    info=native_png(out/(row['id']+'.png'),panels)
    output=out/(row['id']+'.npz')
    np.savez_compressed(output,base=before,**options)
    print(row['id'],len(from_scene.coordinates),{k:(m['active'],round(m['camera_RGB_RMS_DN16'],3))for k,m in summaries.items()},flush=True)
    return {k:row[k] for k in ('id','noise','display_exposure','base_input','output')}|info|{
        'query_xywh':actual,'ROI_raw_xywh':(ix+sx,iy+sy,sw,sh),'donor_count':len(from_scene.coordinates),
        'comparisons':summaries,'npz':reference(output),'raw_source':box,
    }


def main():
    source=reference(BASE)
    old=read_json(checked(source))
    path=ROOT/'standing-parent-phase'
    path.mkdir(exist_ok=True)
    mainconf=reference('configs/gfx-qualitative-20231231.json')
    meshconf=reference('configs/gfx-green-mesh-20231231.json')
    conf,mesh=(read_json(checked(x))for x in (mainconf,meshconf))
    results=[]
    for category,raw_source in (('main',reference(conf['noisy'])),('mesh',mesh['sources']['noisy'])):
        img,info=read_raw(checked(raw_source))
        cfa=np.asarray(color_indices(info.pattern))
        if img.shape[0]%2:
            img=img[:-1]
        if img.shape[1]%2:
            img=img[:,:-1]
        raw=np.stack([img[i//2::2,i%2::2]for i in range(4)])
        del img
        for row in old['rows']:
            if not row['id'].startswith(category+'-'):
                continue
            if category=='mesh':
                origin=mesh['raw_context_xywh'][:2]
            else:
                picked=next(w for w in conf['regions']if row['id'].endswith('-'+w['name']))
                origin=tuple(a-b for a,b in zip(picked['noisy_xy'],row['ROI'][:2],strict=True))
            results.append(process(row,raw,raw_source,origin,cfa,path))
    assert len(results)==8
    write_json(path/'manifest.json',{'driver':reference(__file__),'previous':source,'checkpoint':old['checkpoint'],
                                    'main_config':mainconf,'mesh_config':meshconf,'rows':results})


if __name__=='__main__':
    main()
