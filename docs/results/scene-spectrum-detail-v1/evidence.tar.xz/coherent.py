"""Bound the added modal amplitude with the cross-green power estimate."""
import numpy as np
from scipy.ndimage import uniform_filter
from spectrum import BAND, HALF, N, STRIDE, SYNTH, VALIDATION_Z, GAIN, analyze, green_fft, priors, squares


def compose(raw, cfa, noise, box, donors, before, wb, matrix):
    height,width = raw.shape[-2:]
    yy,xx = np.indices(((height-N)//STRIDE+1,(width-N)//STRIDE+1))
    count = yy.shape
    yy,xx = yy.ravel()*STRIDE,xx.ravel()*STRIDE
    measured = analyze(raw,cfa,noise,yy,xx)
    layout = np.flatnonzero(cfa==1)
    green = before[1]
    parent_blocks = np.stack([green[p//2::2,p%2::2] for p in range(4)])
    retained = green_fft(squares(parent_blocks,yy,xx),layout).mean(axis=1)
    raw_green = measured.green.mean(axis=1)
    axis = raw_green/np.maximum(abs(raw_green),1e-20)
    local_energy = measured.cross[:,BAND].mean(axis=1).reshape(count)
    local_energy = uniform_filter(local_energy,size=3,mode='nearest').ravel()
    local = np.maximum(local_energy-.08,0)[:,None,None]
    choices = priors(measured,donors,box,local)
    r,g,b = np.linalg.solve(matrix,np.ones(3))/wb
    gain_rgb = np.array((r/g,1.,b/g))[:,None,None]
    sums = np.zeros((2*height,2*width),dtype=float)
    for x,y in zip(xx,yy,strict=True):
        sums[y*2:y*2+2*N,x*2:x*2+2*N] += SYNTH**2
    results = {}
    support = {}
    for label, prior in choices.items():
        # Cross-colour phase power uses disjoint actual green sites. A signed test
        # is pooled symmetrically across unique complex modes.
        profile = np.broadcast_to(prior,measured.cross.shape)
        reliability = profile / (profile + .60)
        weight = (.22 + .78 * reliability) * (BAND & HALF)[None]
        z = (weight*measured.cross).sum(axis=(-2,-1)) / np.sqrt(.5*(weight**2).sum(axis=(-2,-1)))
        gate = np.clip((z - VALIDATION_Z)/5,0,1)
        # Unlike the positive-only raw mean, the magnitude needs support in
        # this same modes' cross-power on the two physical green sublattices.
        native_power = measured.cross * measured.noise[:,None,None]
        conservative = np.sqrt(np.maximum(native_power - .75*measured.noise[:,None,None],0.))
        amplitude = np.minimum(abs(raw_green),conservative)
        excess = reliability*amplitude - (retained*axis.conj()).real
        new = GAIN * gate[:,None,None] * np.maximum(excess,0) * axis * BAND[None]
        padded = np.zeros((len(new),2*N,2*N),dtype=complex)
        padded[:,N//2:3*N//2,N//2:3*N//2] = np.fft.fftshift(new,axes=(-2,-1))
        patches = 2 * np.fft.ifft2(np.fft.ifftshift(padded,axes=(-2,-1)),norm='ortho').real
        output = np.zeros_like(sums)
        for x,y,tile in zip(xx,yy,patches,strict=True):
            output[y*2:y*2+2*N,x*2:x*2+2*N] += tile * SYNTH
        gain = output / np.maximum(sums,.16)
        results[label] = before + (gain_rgb * gain[None]).astype(before.dtype)
        support[label] = {'active':int((gate>0).sum()),'z_max':float(z.max()),
                          'mean_gain':float(gate.mean()),'patches':len(gate)}
    return results,support
