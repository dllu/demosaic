"""Use disjoint RAW surroundings to propose a green spectral covariance."""
from dataclasses import dataclass

import numpy as np
from scipy.ndimage import gaussian_filter, uniform_filter

N = 16
STRIDE = 8
HALO = 16
AXIS = np.fft.fftfreq(N, d=2)
FX, FY = np.meshgrid(AXIS, AXIS)
R = np.hypot(FX, FY)
BAND = (R >= .112) & (R < .244)
LOW = (R >= .026) & (R < .095)
HALF = (FX > 0) | ((FX == 0) & (FY > 0))
WINDOW1 = np.sin(np.pi * (np.arange(N) + .5) / N)
WINDOW = WINDOW1[:, None] * WINDOW1
GRID = np.arange(2*N)
SYNTH1 = np.sin(np.pi * (GRID + .5) / (2*N))
SYNTH = SYNTH1[:, None] * SYNTH1
OUT_MODES = ('local','exterior-scalar','exterior-shaped','exterior-transposed')
VALIDATION_Z = 3.
GAIN = .60


@dataclass(frozen=True)
class Tiles:
    coordinates: np.ndarray
    features: np.ndarray
    green: np.ndarray
    noise: np.ndarray
    cross: np.ndarray


def squares(value, yy, xx):
    windows = np.lib.stride_tricks.sliding_window_view(value, (N,N), axis=(-2,-1))
    return np.moveaxis(windows[:, yy, xx], 0, 1)


def green_fft(blocks, layout):
    """Keep both green sublattices in a common native-pixel phase origin."""
    green = blocks[:, layout]
    mean = (green * WINDOW).sum(axis=(-2,-1), keepdims=True) / WINDOW.sum()
    centered = (green - mean) * WINDOW
    shifts = layout % 2
    rows = layout // 2
    correction = np.exp(-2j*np.pi*(FX[None]*shifts[:,None,None] + FY[None]*rows[:,None,None]))
    return np.fft.fft2(centered, norm='ortho') * correction[None]


def analyze(raw, cfa, noise, yy, xx):
    data = squares(raw, yy, xx).astype(float)
    layout = np.flatnonzero(cfa == 1)
    coeff = green_fft(data, layout)
    color = (data * WINDOW).sum(axis=(-2,-1)) / WINDOW.sum()
    r, b = (color[:, np.flatnonzero(cfa==k)[0]] for k in (0,2))
    g = color[:, layout].mean(axis=1)
    power = (noise['shot'] * np.maximum(color[:, layout], 0) + noise['read']).clip(min=2e-11)
    power *= np.mean(WINDOW**2)
    expected = power.mean(axis=1)
    cross = (coeff[:,0] * coeff[:,1].conj()).real / expected[:,None,None]
    cross = cross.clip(-16, 96)
    low = np.maximum(cross[:, LOW], 0)
    angle = np.arctan2(FY[LOW], FX[LOW])
    margin = 1 + low.sum(1)
    features = np.column_stack((np.log(.012+g.clip(min=0)), (r-g)/(.04+g.clip(min=0)), (b-g)/(.04+g.clip(min=0)),
                    np.log1p(low.mean(1)), low@np.cos(2*angle)/margin, low@np.sin(2*angle)/margin))
    return Tiles(np.stack((xx*2+N, yy*2+N),axis=1), features, coeff, expected, cross)


def exterior(raw, cfa, noise, box):
    """Use nearby and strided whole-scene donor windows, excluding the query and halo."""
    x,y,w,h = box
    nrows, ncols = ((v-N)//STRIDE + 1 for v in raw.shape[-2:])
    j,i = np.indices((nrows,ncols))
    xx,yy = i*STRIDE*2,j*STRIDE*2
    outside = (xx+2*N <= x-HALO) | (yy+2*N <= y-HALO) | (xx >= x+w+HALO) | (yy >= y+h+HALO)
    radius = np.maximum(abs(xx+N-x-w/2),abs(yy+N-y-h/2))
    near = (radius <= 500) & (i%2==0) & (j%2==0)
    skip = max(1, int(np.ceil(np.sqrt(nrows*ncols/1024))))
    sampled = outside & (near | ((i%skip==0) & (j%skip==0)))
    if not sampled.any():
        return None
    return analyze(raw,cfa,noise,(j[sampled]*STRIDE),(i[sampled]*STRIDE))


def priors(query, donor, box, local):
    if donor is None:
        return {k:local for k in OUT_MODES}
    x,y,w,h = box
    diff = query.coordinates[:,None] + (x,y) - donor.coordinates[None,:]
    far = np.sum(diff**2,axis=-1)
    distance = -0.5*np.log1p(far/(192**2))*2.2
    scale = np.array([.42,.24,.24,.66,.55,.55])
    texture = (query.features[:,None] - donor.features[None,:]) / scale
    weight = np.exp(distance - .5*np.sum(texture**2,axis=-1))
    total = weight.sum(axis=1)
    # Combine signed donor cross power before clipping and use the Kish effective count.
    count = total**2 / np.maximum(np.sum(weight**2,axis=1),1e-20)
    covariance = (weight @ donor.cross.reshape(len(donor.cross),N*N)) / total[:,None].clip(min=1e-10)
    covariance = gaussian_filter(covariance.reshape(-1,N,N),(0,.65,.65),mode='wrap').clip(min=0)
    confidence = (.60 * count/(count+9) * total/(total+2))[:,None,None]
    scalar = covariance[:,BAND].mean(axis=1)[:,None,None]
    return {'local':local, 'exterior-scalar':local*(1-confidence)+confidence*scalar,
            'exterior-shaped':local*(1-confidence)+confidence*covariance,
            'exterior-transposed':local*(1-confidence)+confidence*covariance.swapaxes(-1,-2)}


def compose(raw, cfa, noise, box, donors, before, wb, matrix):
    height,width = raw.shape[-2:]
    yy,xx = np.indices(((height-N)//STRIDE+1,(width-N)//STRIDE+1))
    count = yy.shape
    yy,xx = yy.ravel()*STRIDE,xx.ravel()*STRIDE
    measured = analyze(raw,cfa,noise,yy,xx)
    layout = np.flatnonzero(cfa==1)
    green = before[1]
    parent_blocks = np.stack([green[p//2::2,p%2::2] for p in range(4)])
    retained = green_fft(squares(parent_blocks,yy,xx),layout).mean(axis=1)
    raw_green = measured.green.mean(axis=1)
    axis = raw_green/np.maximum(abs(raw_green),1e-20)
    local_energy = measured.cross[:,BAND].mean(axis=1).reshape(count)
    local_energy = uniform_filter(local_energy,size=3,mode='nearest').ravel()
    local = np.maximum(local_energy-.08,0)[:,None,None]
    choices = priors(measured,donors,box,local)
    r,g,b = np.linalg.solve(matrix,np.ones(3))/wb
    gain_rgb = np.array((r/g,1.,b/g))[:,None,None]
    sums = np.zeros((2*height,2*width),dtype=float)
    for x,y in zip(xx,yy,strict=True):
        sums[y*2:y*2+2*N,x*2:x*2+2*N] += SYNTH**2
    results = {}
    support = {}
    for label, prior in choices.items():
        # Cross-colour phase power uses disjoint actual green sites. A signed test
        # is pooled symmetrically across unique complex modes.
        profile = np.broadcast_to(prior,measured.cross.shape)
        reliability = profile / (profile + .60)
        weight = (.22 + .78 * reliability) * (BAND & HALF)[None]
        z = (weight*measured.cross).sum(axis=(-2,-1)) / np.sqrt(.5*(weight**2).sum(axis=(-2,-1)))
        gate = np.clip((z - VALIDATION_Z)/5,0,1)
        excess = (reliability*raw_green-retained)*axis.conj()
        new = GAIN * gate[:,None,None] * np.maximum(excess.real,0) * axis * BAND[None]
        padded = np.zeros((len(new),2*N,2*N),dtype=complex)
        padded[:,N//2:3*N//2,N//2:3*N//2] = np.fft.fftshift(new,axes=(-2,-1))
        patches = 2 * np.fft.ifft2(np.fft.ifftshift(padded,axes=(-2,-1)),norm='ortho').real
        output = np.zeros_like(sums)
        for x,y,tile in zip(xx,yy,patches,strict=True):
            output[y*2:y*2+2*N,x*2:x*2+2*N] += tile * SYNTH
        gain = output / np.maximum(sums,.16)
        results[label] = before + (gain_rgb * gain[None]).astype(before.dtype)
        support[label] = {'active':int((gate>0).sum()),'z_max':float(z.max()),
                          'mean_gain':float(gate.mean()),'patches':len(gate)}
    return results,support
