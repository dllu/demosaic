"""Show the observed camera effect of requiring nonzero parent spectral amplitude."""
from pathlib import Path

from PIL import Image, ImageDraw
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import ROOT


def main():
    refs={k:reference(ROOT/f'standing-{k}/manifest.json')for k in ('parent-phase','phase-floor')}
    old=read_json(checked(refs['parent-phase']))
    new=read_json(checked(refs['phase-floor']))
    output=Path('docs/images/scene-spectrum-detail-v1')
    plates=[]
    for key in ('main','mesh'):
        sheet=Image.new('RGB',(680,708),'#eeeeee')
        captions=ImageDraw.Draw(sheet)
        names=('Preceding result','Parent phase','With phase floor','ISO100 AHD reference')
        for col,name in enumerate(names):
            captions.text((8+col*168,6),name,fill='black')
        reviewed=[]
        for i,(a,b) in enumerate((a,b)for a,b in zip(old['rows'],new['rows'],strict=True)if a['id'].startswith(key)):
            assert a['id']==b['id'] and a['ROI_raw_xywh']==b['ROI_raw_xywh']
            y=21+171*i
            images={}
            for mode,row in (('parent-phase',a),('phase-floor',b)):
                with Image.open(checked(row['image'])) as image:
                    boxes={p['name']:p['png_xywh'] for p in row['panels']}
                    for k in ('Exterior-frequency colour','Exterior spectral shape','ISO100 AHD reference'):
                        x1,y1,w,h=boxes[k]
                        assert w==h==160
                        images[mode,k]=image.crop((x1,y1,x1+w,y1+h)).convert('RGB')
            rows=(( 'parent-phase','Exterior-frequency colour'), ('parent-phase','Exterior spectral shape'),
                  ('phase-floor','Exterior spectral shape'),('phase-floor','ISO100 AHD reference'))
            for ix,m in enumerate(rows):
                sheet.paste(images[m],(8+168*ix,y))
            captions.text((8,y+160),b['id'],fill='black')
            reviewed.append(b['id'])
        loc=output/f'{key}-phase-floor.png'
        sheet.save(loc,optimize=True)
        plates.append({'image':reference(loc),'rows':reviewed,'cell':[160,160],'order':names})
    write_json(ROOT/'floor-native.json',{'driver':reference(__file__),'sources':refs,'boards':plates})

if __name__=='__main__':
    main()
