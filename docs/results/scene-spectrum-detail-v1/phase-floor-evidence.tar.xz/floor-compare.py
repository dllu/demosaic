"""Bind noise stress, exact-target replay and camera pixels with the phase floor."""
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import ROOT


def main():
    select='exterior-shaped'
    sources={label:reference(ROOT/f'standing-{label}/manifest.json')for label in ('parent-phase','phase-floor')}
    old=read_json(checked(sources['parent-phase']))
    actual=read_json(checked(sources['phase-floor']))
    comparisons=[]
    for a,b in zip(old['rows'],actual['rows'],strict=True):
        assert a['id']==b['id'] and a['ROI_raw_xywh']==b['ROI_raw_xywh']
        dx,dy=(p-q for p,q in zip(b['ROI_raw_xywh'][:2],b['query_xywh'][:2],strict=True))
        roi=np.s_[...,dy:dy+160,dx:dx+160]
        with np.load(checked(a['npz']),allow_pickle=False)as f,np.load(checked(b['npz']),allow_pickle=False)as g:
            np.testing.assert_array_equal(f['base'],g['base'])
            diff=(f[select][roi].astype(float)-g[select][roi])*65535
        comparisons.append({'id':b['id'],'noise':b['noise'],'ROI':b['ROI_raw_xywh'],
             'view':b['image'],'values':b['comparisons'][select],
             'RMS_above_previous_phase_rule_DN16':float(np.sqrt(np.mean(diff**2)))})
    score=reference(ROOT/'phase-floor-results.json')
    stress=reference(ROOT/'noise-audit-floor.json')
    write_json(ROOT/'floor-compare.json',{'driver':reference(__file__),'prediction':sources,
          'camera':comparisons,'exact':score,'exact_summary':read_json(checked(score))['summary'],
          'stress':stress,'noisy_flat_summary':read_json(checked(stress))['summary']})


if __name__=='__main__':
    main()
