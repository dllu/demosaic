"""Stress the query green agreement gate with equal-variance correlated noise."""
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import reference, write_json
import spectrum, coherent, parent_phase, phase_floor

ROOT=Path(__file__).resolve().parent
N=128
LEVEL=.085
SHOT=.00128
READ=6.5536e-6
VAR=SHOT*LEVEL+READ
LAYOUTS=np.array(((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0)))
BRANCHES={'raw-mean':spectrum,'cross-power':coherent,'parent-phase':parent_phase,'phase-floor':phase_floor}
POLICY='exterior-shaped'


def main():
    rng=np.random.default_rng(652204035)
    origin=(128,128,256,256)
    size=256
    rows=[]
    for index in range(48):
        layout=LAYOUTS[index%4]
        y,x=np.indices((size,size),dtype=float)
        palette=np.repeat((x>=128).astype(float)[None],4,axis=0)
        patterned=np.full((4,size,size),LEVEL)
        patterned += .012 * palette*np.cos(2*np.pi*.125*x)[None] * (1+.2*np.sin(y/12)[None])
        pattern = {'shot':SHOT,'read':READ}
        exterior=spectrum.exterior(patterned.astype(np.float32),layout,pattern,origin)
        parent=np.full((3,2*N,2*N),LEVEL,dtype=np.float32)
        for category,fraction in (('independent',0.),('shared-row',.05),('shared-column',.05)):
            iid=rng.standard_normal((4,N,N))
            if category=='shared-row':
                base=rng.standard_normal((1,N,1))
            elif category=='shared-column':
                base=rng.standard_normal((1,1,N))
            else:
                base=0.
            noise=np.sqrt(VAR)*((1-fraction)**.5*iid+fraction**.5*base)
            raw=(LEVEL+noise).astype(np.float32)
            roi=np.s_[...,48:208,48:208]
            measures={}
            for name,branch in BRANCHES.items():
                values,support=branch.compose(raw,layout,pattern,origin,exterior,parent,np.ones(3),np.eye(3))
                diff=(values[POLICY][roi].astype(float)-parent[roi])*65535
                measures[name]={'added_DN16':float(np.sqrt(np.mean(diff*diff))),
                                 'changed':bool(np.any(diff)),'maximum_DN16':float(abs(diff).max()),
                                 'gated_windows':support[POLICY]['active']}
            rows.append({'pattern':layout.tolist(),'index':index,'family':category,'shared_variance_fraction':fraction,'comparisons':measures})
    pooled={}
    for kind in ('independent','shared-row','shared-column'):
        cases=[r['comparisons']for r in rows if r['family']==kind]
        pooled[kind]={mode:{'changed':sum(r[mode]['changed']for r in cases),
                            'added_RMS_mean_DN16':float(np.mean([r[mode]['added_DN16']for r in cases])),
                            'peak_DN16':max(r[mode]['maximum_DN16']for r in cases)} for mode in BRANCHES}
    write_json(ROOT/'noise-audit-floor.json',{'driver':reference(__file__),'rows':rows,'summary':pooled,
              'scope':'48 exact-flat query replays per family. Shared packed rows or columns contribute 5% of total variance, with matching marginal per-site variance. Synthetic stress case with deterministic exterior and ideal flat inference parent.'})
    print(pooled)

if __name__=='__main__':
    main()
