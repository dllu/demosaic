"""Review the fresh observations with paired fixed and matched-quiet comparisons."""

from collections import Counter
from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI, evaluated, measure, scale_at_budget
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def direct(parent, truth, quiet, prediction, alpha):
    emitted = parent.copy()
    emitted[ROI] += alpha * (prediction.astype(np.float64) - parent[ROI])
    error = emitted - truth
    weak = truth[2] - truth[1]
    strong = truth[1] - truth[0]
    return {
        "quiet_mse": np.mean((error[ROI][..., quiet] * 65535) ** 2),
        "query_mse": np.mean((error[ROI] * 65535) ** 2),
        "weak_increment_mse": np.mean(((error[2] - error[1]) * 65535) ** 2),
        "weak_gain": np.vdot(emitted[2] - emitted[1], weak) / np.vdot(weak, weak),
        "strong_gain": np.vdot(emitted[1] - emitted[0], strong) / np.vdot(strong, strong),
        "weak_absent_projection": np.vdot(error[1], weak) / np.vdot(weak, weak),
        "background_quiet_mse": np.mean((error[0][ROI][..., quiet] * 65535) ** 2),
    }


def load(case):
    with np.load(checked(case["parent"])) as f:
        parent = f["parent"].astype(np.float64)
    with np.load(checked(case["target"])) as f:
        truth, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
    with np.load(checked(case["prediction"])) as f:
        predictions = dict(f)
    return parent, truth, quiet, predictions


def score(rows, arms, scale):
    moments = []
    for row in rows:
        p, gt, q, pred = load(row)
        moments.append({arm: measure(p, gt, q, pred[arm]) for arm in arms})
    means = {
        arm: {k: np.mean([m[arm][k] for m in moments], axis=0) for k in moments[0][arm]}
        for arm in arms
    }
    fixed = {arm: evaluated(v, scale) for arm, v in means.items()}
    limit = min(fixed[arm]["quiet_RMS_DN16"] for arm in arms if arm != "parent")
    budget = max(0.0, limit - fixed["parent"]["quiet_RMS_DN16"])
    weights = {arm: min(scale, scale_at_budget(v["quiet_mse"], budget)) for arm, v in means.items()}
    products = {"fixed": {}, "matched": {}}
    for arm in arms:
        for mode, alpha in (("fixed", scale), ("matched", weights[arm])):
            direct_rows = []
            for row in rows:
                p, gt, q, pred = load(row)
                actual = direct(p, gt, q, pred[arm], alpha)
                direct_rows.append(actual)
            actual = {
                (k.replace("_mse", "_RMS_DN16") if k.endswith("_mse") else k): (
                    float(np.sqrt(np.mean([r[k] for r in direct_rows])))
                    if k.endswith("_mse")
                    else float(np.mean([r[k] for r in direct_rows]))
                )
                for k in direct_rows[0]
            }
            for key, value in evaluated(means[arm], alpha).items():
                np.testing.assert_allclose(actual[key], value, atol=1e-9, rtol=1e-9)
            products[mode][arm] = actual | {"scale": alpha}
    return products


def main():
    source_path = ROOT / "output/collection.json"
    result = read_json(source_path)
    plan = read_json(checked(result["plan"]))
    rows = [read_json(checked(row)) for row in result["cases"]]
    assert [v["id"] for v in plan["groups"]] == [v["id"] for v in rows]
    assert {v["source"] for v in rows} == set(range(88, 96))
    out = ROOT / "review"
    out.mkdir()
    aggregate, boards, witness = [], [], {}
    for profile, operating in plan["settings"].items():
        for zone in ("all", "distinct", "same-paint"):
            active = [
                q
                for q in rows
                if q["profile"] == profile and (zone == "all" or q["appearance"] == zone)
            ]
            counts = {arm: Counter() for arm in plan["arms"][1:]}
            for case in active:
                if case["id"] not in witness:
                    identities = case["metadata"]["identities"] + [
                        x["identity"] for x in case["donors"]
                    ]
                    assert len(set(identities)) == 7
                    checked(case["sensor"])
                    for donor in case["donors"]:
                        checked(donor["raw"])
                    truth_boxes = {tuple(x["box"]) for x in case["donors"][:2]}
                    facts = []
                    for role in case["rankings"]:
                        items = {}
                        for arm, fit in role["fits"].items():
                            boxes = {tuple(x) for x in fit.get("donor_boxes", [])}
                            items[arm] = (
                                "intended"
                                if boxes == truth_boxes
                                else "alternate"
                                if boxes
                                else "none"
                            )
                        facts.append(items)
                    witness[case["id"]] = facts
                for arm, status in witness[case["id"]][2].items():
                    counts[arm][status] += 1
            aggregate.append(
                {
                    "profile": profile,
                    "appearance": zone,
                    "count": len(active),
                    "role2_brackets": counts,
                }
                | score(active, plan["arms"], operating["scale"])
            )
    for case in rows:
        if (case["profile"], case["source"]) not in (("iso400", 88), ("iso400", 89)):
            continue
        p, target, _, pred = load(case)
        scale = plan["settings"][case["profile"]]["scale"]
        with np.load(checked(case["sensor"])) as f:
            ctx = {k: f[k][2:3] for k in ("colors", "wb", "matrix")}
            ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
        base = p[2][ROI]
        boards.append(
            native_board(
                out,
                case["id"],
                [
                    noisy_malvar(ctx)[0],
                    *(base + scale * (pred[arm][2] - base) for arm in plan["arms"]),
                    target[2][ROI],
                ],
                ctx,
                {
                    "case_receipt": next(
                        v for v in result["cases"] if Path(v["path"]).stem == case["id"]
                    )
                },
                labels=[
                    "Noisy Malvar",
                    "V143 EMA",
                    "Spectral rank",
                    "Weighted context",
                    "Near affinity",
                    "Scene affinity",
                    "Exact GT",
                ],
                triplet_indices=(0, 5, 6),
                contrast=5,
            )
        )
    write_json(
        out / "result.json",
        {
            "producer": reference(__file__),
            "source": reference(source_path),
            "aggregates": aggregate,
            "choices_by_role": witness,
            "boards": boards,
            "verified_direct_reductions": True,
        },
    )


if __name__ == "__main__":
    main()
