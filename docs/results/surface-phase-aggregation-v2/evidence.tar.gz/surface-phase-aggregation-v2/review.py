"""Review matched quiet levels, held-out source mixtures and native outputs."""

import importlib.util
from pathlib import Path

import numpy as np
from probe_surface_aggregation import MODES, field
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.surface_phase_aggregation import bound_phase_average

ROOT = Path(__file__).resolve().parent
SCORER = ROOT.parent / "affinity-first-fresh-v3/review.py"
spec = importlib.util.spec_from_file_location("existing_direct_scorer", SCORER)
direct = importlib.util.module_from_spec(spec)
spec.loader.exec_module(direct)
GUIDES = ("scene", "exact-center")
BLENDS = (0.0, 0.25, 0.5, 0.75, 1.0)
REVIEW_MODES = (*MODES, "bounded-tangent")


def bounded(values, guide, offset):
    return bound_phase_average(
        values["parent"],
        values[field(guide, "weighted-refit", offset)],
        values[field(guide, "tangent-predictive-gate", offset)],
    )


def averaged(rows, arm):
    return {
        k: np.mean([r["moments"][arm][k] for r in rows], axis=0) for k in rows[0]["moments"][arm]
    }


def capped(moment, ceiling, maximum):
    budget = max(0, ceiling - evaluated(moment, 0)["quiet_RMS_DN16"])
    alpha = min(maximum, scale_at_budget(moment["quiet_mse"], budget))
    return evaluated(moment, alpha) | {"scale": alpha}


def ensemble(rows, guide, maximum):
    """Select a blend on the seven other geometries under their paired quiet limit."""
    control = field(guide, "weighted-refit", 0)
    labels = {t: f"{guide}-mix{t:g}" for t in BLENDS}
    decisions = []
    for row in rows:
        fit = [other for other in rows if other["id"] != row["id"]]
        baseline = evaluated(averaged(fit, control), maximum)
        results = {
            t: capped(averaged(fit, label), baseline["quiet_RMS_DN16"], maximum)
            for t, label in labels.items()
        }
        eligible = {
            t: r
            for t, r in results.items()
            if r["weak_increment_RMS_DN16"] <= baseline["weak_increment_RMS_DN16"] + 1e-10
        }
        choice = max(eligible, key=lambda t: (eligible[t]["weak_gain"], -t))
        alpha = eligible[choice]["scale"]
        held = evaluated(row["moments"][labels[choice]], alpha)
        old = evaluated(row["moments"][control], maximum)
        decisions.append(
            {
                "id": row["id"],
                "tangent_fraction": choice,
                "scale": alpha,
                "measured": held,
                "control": old,
            }
        )
    aggregate = {}
    for mode in ("measured", "control"):
        output = {}
        for key in decisions[0][mode]:
            values = np.asarray([r[mode][key] for r in decisions])
            output[key] = float(
                np.sqrt(np.mean(values**2)) if key.endswith("_RMS_DN16") else values.mean()
            )
        aggregate[mode] = output
    return {"aggregate": aggregate, "by_source": decisions}


def synth(rows, plan, out):
    cases, boards, verified = [], [], 0
    arms = ["parent", *(field(g, m, t) for g in GUIDES for m in REVIEW_MODES for t in (0, 1))]
    for row in rows:
        case = read_json(checked(row["case"]))
        parents, truth, quiet, pred = direct.load(case | {"prediction": row["prediction"]})
        for g in GUIDES:
            for t in (0, 1):
                pred[field(g, "bounded-tangent", t)] = np.stack(
                    [
                        bounded({name: value[role] for name, value in pred.items()}, g, t)
                        for role in range(3)
                    ]
                )
        with np.load(checked(row["previous"])) as saved:
            np.testing.assert_array_equal(pred["parent"], saved["parent"])
            verified += 1
            for g in GUIDES:
                for stop in (0, 1):
                    f = field(g, "weighted-refit", stop)
                    np.testing.assert_array_equal(pred[f], saved[f"parallel-{f}"])
                    verified += 1
        moments = {a: measure(parents, truth, quiet, pred[a]) for a in arms}
        for g in GUIDES:
            base = pred[field(g, "weighted-refit", 0)].astype(float)
            tangent = pred[field(g, "bounded-tangent", 0)].astype(float)
            for fraction in BLENDS:
                moments[f"{g}-mix{fraction:g}"] = measure(
                    parents, truth, quiet, base + fraction * (tangent - base)
                )
        bg = {}
        for arm in arms:
            d = (pred[arm][0].astype(float) - pred["parent"][0]) * 65535
            bg[arm] = {
                "changed_native_pixels": int(
                    np.count_nonzero(np.any(d[:, 48:208, 48:208] != 0, axis=0))
                ),
                "quiet_added_RMS_DN16": float(np.sqrt(np.mean(d[:, quiet] ** 2))),
            }
        nominal = plan["settings"][case["profile"]]["scale"]
        for n in arms:
            row_direct = direct.direct(parents, truth, quiet, pred[n], nominal)
            row_poly = evaluated(moments[n], nominal)
            for k, v in row_direct.items():
                if k != "background_quiet_mse":
                    expected = np.sqrt(v) if k.endswith("_mse") else v
                    np.testing.assert_allclose(
                        row_poly[k.replace("_mse", "_RMS_DN16")], expected, atol=2e-8, rtol=2e-8
                    )
        cases.append(
            {
                "id": row["id"],
                "profile": case["profile"],
                "paint": case["appearance"],
                "moments": moments,
                "no_wire": bg,
            }
        )
        if case["profile"] != "iso400" or case["source"] not in (88, 89):
            continue
        with np.load(checked(case["sensor"])) as f:
            ctx = {k: f[k][2:3] for k in ("colors", "wb", "matrix")}
            ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
        p = parents[2][ROI]
        render = {
            "scene-weighted-refit": "Scene wave refit",
            "scene-square-average": "Square average",
            "scene-tangent-average": "Tangent average",
            "scene-tangent-predictive-gate": "Tangent / wave gate",
            "scene-bounded-tangent": "Tangent energy cap",
            "exact-center-weighted-refit": "Exact guide wave",
            "exact-center-tangent-predictive-gate": "Exact guide average",
        }
        pixels = [
            noisy_malvar(ctx)[0],
            p,
            *(p + nominal * (pred[k][2] - p) for k in render),
            truth[2][ROI],
        ]
        boards.append(
            native_board(
                out,
                case["id"],
                pixels,
                ctx,
                {
                    "case_receipt": row["case"],
                    "CFA": case["CFA"],
                    "noise": case["metadata"]["noise"],
                    "checkpoint": plan["parent_checkpoint"],
                    "operating": plan["settings"][case["profile"]],
                },
                labels=["Noisy Malvar", "V143 EMA", *render.values(), "Exact GT"],
                triplet_indices=(0, 6, 9),
                contrast=5,
            )
        )
    results = []
    for profile, opts in plan["settings"].items():
        nominal = opts["scale"]
        for paint in ("all", "same-paint", "distinct"):
            pool = [
                r
                for r in cases
                if r["profile"] == profile and (paint == "all" or r["paint"] == paint)
            ]
            for guide in GUIDES:
                keys = ["parent", *(field(guide, m, t) for m in REVIEW_MODES for t in (0, 1))]
                means = {a: averaged(pool, a) for a in keys}
                fixed = {a: evaluated(m, nominal) for a, m in means.items()}
                ceiling = max(
                    fixed["parent"]["quiet_RMS_DN16"],
                    fixed[field(guide, "weighted-refit", 0)]["quiet_RMS_DN16"],
                )
                matched = {a: capped(m, ceiling, nominal) for a, m in means.items()}
                results.append(
                    {
                        "profile": profile,
                        "paint": paint,
                        "guide": guide,
                        "count": len(pool),
                        "quiet_ceiling_DN16": ceiling,
                        "fixed": fixed,
                        "matched": matched,
                        **({"mixture": ensemble(pool, guide, nominal)} if paint == "all" else {}),
                    }
                )
    return (
        results,
        [{k: v for k, v in row.items() if k != "moments"} for row in cases],
        boards,
        verified,
    )


def real(rows, plan, out):
    baseline = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    render = {
        "scene-weighted-refit": "Scene wave refit",
        "scene-square-average": "Square average",
        "scene-tangent-average": "Tangent average",
        "scene-tangent-predictive-gate": "Tangent / wave gate",
        "scene-bounded-tangent": "Tangent energy cap",
        "spectral-weighted-refit": "Spectra wave refit",
        "spectral-tangent-average": "Spectra tangent",
        "spectral-tangent-predictive-gate": "Spectra / wave gate",
        "spectral-bounded-tangent": "Spectra energy cap",
    }
    camera, verified = [], 0
    for old, row in zip(baseline, rows, strict=True):
        key, source = old["id"], old["source"]
        assert key == row["id"]
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = source["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(row["predictions"])) as f:
            pixels = dict(f)
        for guide in row["fits"]:
            for t in (0, 1):
                pixels[field(guide, "bounded-tangent", t)] = bounded(pixels, guide, t)
        with np.load(checked(row["previous"])) as f:
            np.testing.assert_array_equal(pixels["parent"], f["parent"])
            verified += 1
            for guide in row["fits"]:
                for t in (0, 1):
                    name = field(guide, "weighted-refit", t)
                    np.testing.assert_array_equal(pixels[name], f[f"parallel-{name}"])
                    verified += 1
        with np.load(checked(source["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = old["display_exposure"]
        added = [
            (
                label,
                np.rint(
                    display(pixels[name][None], ctx, exposure=exposure)[0][region].transpose(
                        1, 2, 0
                    )
                    * 255
                ).astype(np.uint8),
            )
            for name, label in render.items()
        ]
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, positions = insert_camera_panels(
            out, key, old | {"panels": panels}, "V120 EMA", added
        )
        parent = pixels["parent"][region]
        dx, dy, *_ = source["absolute_query_xywh"]
        camera.append(
            {
                "id": key,
                "image": image,
                "panels": positions,
                "checkpoint": source["checkpoint"],
                "display_exposure": exposure,
                "noise": noise[key],
                "ROI_xywh": [x - qx + dx, y - qy + dy, w, h],
                "camera_RAW": plan["photos"]["main" if key.startswith("main-") else "mesh"],
                "calibration": source["query_arrays"],
                "predictions": row["predictions"],
                "guides": row["fits"],
                "distance_DN16": {
                    k: float(np.sqrt(np.mean((v[region].astype(float) - parent) ** 2)) * 65535)
                    for k, v in pixels.items()
                },
            }
        )
    return camera, verified


def main():
    path = ROOT / "output/collection.json"
    output = read_json(path)
    plan = read_json(checked(output["plan"]))
    out = ROOT / "review"
    out.mkdir()
    total, quiet, boards, checked_synth = synth(output["synthetic"], plan, out)
    camera, checked_camera = real(output["camera"], plan, out)
    write_json(
        out / "result.json",
        {
            "collection": reference(path),
            "producer": reference(__file__),
            "direct_score": reference(SCORER),
            "energy_cap_source": reference("src/demosaic/surface_phase_aggregation.py"),
            "by_group": total,
            "no_wire": quiet,
            "boards": boards,
            "camera": camera,
            "verified_arrays": checked_synth + checked_camera,
        },
    )


if __name__ == "__main__":
    main()
