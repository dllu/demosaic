"""Replay the same 36 forced-guide flat, step and rail controls."""

import importlib.util
from collections import Counter
from pathlib import Path

import numpy as np
import torch
from probe_surface_aggregation import deliver

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig
from demosaic.surface_phase_aggregation import bound_phase_average

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "matched-query-evidence-v1/structure_null.py"
spec = importlib.util.spec_from_file_location("closed_structure_null", SOURCE)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    plan = read_json(ROOT / "plan.json")
    cfg = LocalWaveConfig(**plan["config"])
    old_path = ROOT.parent / "query-rail-background-v1/structure-replay.json"
    previous = read_json(old_path)
    profiles = {n: i for i, n in enumerate(plan["profiles"])}
    styles = {n: i for i, n in enumerate(("flat", "step", "rail"))}
    rows, counts = [], Counter()
    for row in previous["rows"]:
        profile, style, trial = row["profile"], row["style"], row["trial"]
        noise = plan["profiles"][profile]
        colors = np.array(PATTERNS[row["CFA"]])
        truth = original.construct(style, row["angle_radians"], *row["width_shift_level_height"])
        seed = [original.SEED, 1, profiles[profile], styles[style], trial]
        samples = original.corrupt(
            truth, colors, np.random.default_rng(np.random.SeedSequence(seed)), noise
        )
        guides = {"null": {"active": [True, True], "frequencies_xy": row["guide_frequencies_xy"]}}
        threshold = plan["settings"][profile]["threshold"]
        prediction, _ = deliver(
            truth, samples, colors, guides, noise, original.QUERY, cfg, threshold
        )
        for suffix in ("", "-strict"):
            prediction[f"null-bounded-tangent{suffix}"] = bound_phase_average(
                truth,
                prediction[f"null-weighted-refit{suffix}"],
                prediction[f"null-tangent-predictive-gate{suffix}"],
            )
        values = {}
        for label, output in prediction.items():
            if label == "parent":
                continue
            delta = (output[original.MEASURE].astype(float) - truth[original.MEASURE]) * 65535
            values[label] = {
                "RMS_DN16": float(np.sqrt(np.mean(delta**2))),
                "max_abs_DN16": float(np.max(np.abs(delta))),
                "changed_pixels": int(np.any(delta != 0, axis=0).sum()),
            }
            if "weighted-refit" in label:
                assert values[label] == row["metrics"][f"parallel-{label}"]
            counts[profile, style, label] += values[label]["changed_pixels"] > 0
        rows.append({k: row[k] for k in ("profile", "style", "trial", "CFA")} | {"metrics": values})
        print(profile, style, trial, [round(v["RMS_DN16"], 4) for v in values.values()], flush=True)
    write_json(
        ROOT / "null-replay.json",
        {
            "plan": reference(ROOT / "plan.json"),
            "producer": reference(__file__),
            "source": reference(old_path),
            "construct_and_corrupt": reference(SOURCE),
            "energy_cap_source": reference("src/demosaic/surface_phase_aggregation.py"),
            "trials": previous["trials"],
            "scope": previous["scope"],
            "false_changes": {" / ".join(k): v for k, v in counts.items()},
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main()
