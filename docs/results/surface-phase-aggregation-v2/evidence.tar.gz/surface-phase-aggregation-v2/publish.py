"""Publish the inspected native boards and exact phase-pooling receipts."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
earlier = root.parent / "surface-phase-aggregation-v1"
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
report = read_json(root / "review/result.json")
collection = read_json(checked(report["collection"]))
plan = read_json(checked(collection["plan"]))
nulls = read_json(root / "null-replay.json")
before = read_json(earlier / "null-replay.json")
disjoint = read_json(root / "disjoint-panel.json")
assert len(report["boards"]) == 2 and len(report["camera"]) == 8
assert len(nulls["rows"]) == len(before["rows"]) == 36
assert len(disjoint["rows"]) == 16
assert report["verified_arrays"] == 120
assert collection["restoration_calls"] == 0
assert report["energy_cap_source"] == nulls["energy_cap_source"] == disjoint["energy_cap_source"]
for a, b in zip(nulls["rows"], before["rows"], strict=True):
    assert all(a[k] == b[k] for k in ("profile", "style", "trial", "CFA"))
    for key, val in b["metrics"].items():
        assert a["metrics"][key] == val
images.mkdir()
results.mkdir()


def adopt(binding):
    source = checked(binding)
    output = images / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return output.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Ten native comparison boards and two native triplets inspected. "
        "Camera ISO100 AHD and JPEGs are independent references.",
        "phase_aggregation": plan["phase_averages"],
        "synthetic": [
            r | {k: r[k] | {"file": adopt(r[k]["image"])} for k in ("board", "triplet")}
            for r in report["boards"]
        ],
        "camera": [
            {k: v for k, v in r.items() if k not in ("distance_DN16", "guides")}
            | {
                "file": adopt(r["image"]),
                "CFA": "RGGB",
                "reference": "DSCF3880 ISO100 AHD"
                if r["id"].startswith("main-")
                else "DSCF3835 ISO100 AHD and DSCF3842/DSCF3835 camera JPEGs",
            }
            for r in report["camera"]
        ],
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {
        "collection": report["collection"],
        "plan": collection["plan"],
        "energy_cap_source": report["energy_cap_source"],
        "CPU_wall_seconds": collection["CPU_wall_seconds"],
        "verified_arrays": report["verified_arrays"],
        "results": report["by_group"],
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "distance_DN16", "checkpoint", "noise")}
            for r in report["camera"]
        ],
        "structure_null": {
            "source": reference(root / "null-replay.json"),
            "unbounded_control_replay_exact": True,
            "counts": nulls["false_changes"],
            "rows": nulls["rows"],
        },
        "disjoint": {
            "source": reference(root / "disjoint-panel.json"),
            "by_profile": disjoint["by_profile"],
            "CPU_wall_seconds": disjoint["CPU_wall_seconds"],
            "count": len(disjoint["rows"]),
        },
    },
)
bound = checked(report["energy_cap_source"])
members = {
    root: [
        "plan.json",
        "collect.log",
        "output/collection.json",
        "review/result.json",
        "review.py",
        "null_replay.py",
        "null-replay.json",
        "null-replay.log",
        "disjoint_panel.py",
        "disjoint-panel.log",
        "disjoint-panel.json",
        "bound-tests.log",
        "tests.log",
        "publish.py",
        "work/src/demosaic/phase_aggregation.py",
        "work/src/demosaic/local_validated_waves.py",
        "work/src/demosaic/surface_phase_aggregation.py",
        "work/scripts/probe_surface_aggregation.py",
    ],
    earlier: [
        "plan.json",
        "collect.log",
        "work/src/demosaic/surface_phase_aggregation.py",
        "null_replay.py",
        "null-replay-import-failure.log",
        "null-replay.json",
        "null-replay.log",
        "tests.log",
    ],
    root.parent / "affinity-first-fresh-v3": ["review.py"],
    root.parent / "matched-query-evidence-v1": ["structure_null.py"],
    bound.parent: [bound.name],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as encoded,
    tarfile.open(fileobj=encoded, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            path = folder / name
            entry = bundle.gettarinfo(str(path), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with path.open("rb") as blob:
                bundle.addfile(entry, blob)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
