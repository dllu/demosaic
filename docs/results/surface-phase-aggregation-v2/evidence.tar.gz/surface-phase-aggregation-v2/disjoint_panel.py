"""Check the same estimator on archived sources disjoint from the main replay."""

import time
from pathlib import Path

import numpy as np
import torch
from probe_donor_phase_geometry import sensor_box
from probe_fresh_phase_refit import write_array
from probe_screened_scene_donors import offset_box
from probe_surface_aggregation import deliver
from report_fold_support_pooling import ROI, evaluated, measure, scale_at_budget

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig
from demosaic.surface_phase_aggregation import bound_phase_average

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "affinity-first-donors-v1/output/collection.json"
ARM = ("parent", "scene-weighted-refit", "scene-tangent-predictive-gate", "scene-bounded-tangent")


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    start = time.monotonic()
    p = ROOT / "plan.json"
    plan = read_json(p)
    archived = read_json(SOURCE)
    old_plan = read_json(checked(archived["plan"]))
    assert plan["parent_checkpoint"] == old_plan["parent_checkpoint"]
    assert plan["query_xywh"] == old_plan["query_xywh"]
    cfg = LocalWaveConfig(**plan["config"])
    query = offset_box(plan["query_xywh"])
    out = ROOT / "disjoint-predictions"
    out.mkdir()
    rows = []
    for row in archived["synthetic"]:
        case = read_json(checked(row["case"]))
        if case["placement"] != "far":
            continue
        profile = case["profile"]
        setting = plan["settings"][profile]
        noise = plan["profiles"][profile]
        parent = np.load(checked(case["parent"])).astype(np.float64)
        with np.load(checked(case["target"])) as f:
            truth = f["target"].astype(float)
            quiet = f["quiet"][ROI]
        packed, colors = sensor_box(case["sensor"], plan["query_xywh"])
        values = []
        for rgb, raw, cfa, witness in zip(
            parent[ROI], packed, colors, row["rankings"], strict=True
        ):
            fit = witness["fits"]["scene"]
            local, _ = deliver(
                rgb, raw, cfa, {"scene": fit}, noise, query, cfg, setting["threshold"]
            )
            local["scene-bounded-tangent"] = bound_phase_average(
                local["parent"],
                local["scene-weighted-refit"],
                local["scene-tangent-predictive-gate"],
            )
            values.append(local)
        predicted = {a: np.stack([r[a] for r in values]) for a in ARM}
        moments = {
            a: {k: v.tolist() for k, v in measure(parent, truth, quiet, predicted[a]).items()}
            for a in ARM
        }
        rows.append(
            {
                "id": row["id"],
                "profile": profile,
                "source": case["source"],
                "prediction": write_array(out / f"{row['id']}.npz", **predicted),
                "case": row["case"],
                "moments": moments,
            }
        )
        print(len(rows), row["id"], flush=True)
    assert len(rows) == 16 and {r["source"] for r in rows} == set(range(80, 88))
    results = []
    for profile, setting in plan["settings"].items():
        pool = [r["moments"] for r in rows if r["profile"] == profile]
        mean = {a: {k: np.mean([r[a][k] for r in pool], axis=0) for k in pool[0][a]} for a in ARM}
        scale = setting["scale"]
        fixed = {a: evaluated(m, scale) for a, m in mean.items()}
        floor = fixed["parent"]["quiet_RMS_DN16"]
        ceiling = max(floor, fixed["scene-weighted-refit"]["quiet_RMS_DN16"])
        scales = {
            a: min(scale, scale_at_budget(m["quiet_mse"], ceiling - floor)) for a, m in mean.items()
        }
        constrained = {a: evaluated(m, scales[a]) | {"scale": scales[a]} for a, m in mean.items()}
        results.append(
            {
                "profile": profile,
                "quiet_ceiling_DN16": ceiling,
                "fixed": fixed,
                "matched": constrained,
            }
        )
    write_json(
        ROOT / "disjoint-panel.json",
        {
            "plan": reference(p),
            "producer": reference(__file__),
            "inputs": reference(SOURCE),
            "energy_cap_source": reference("src/demosaic/surface_phase_aggregation.py"),
            "rows": rows,
            "by_profile": results,
            "CPU_wall_seconds": time.monotonic() - start,
            "scope": "Sixteen archived far-edge observations, sources 80–87 with full-frame "
            "donor fits from the appearance-first experiment. The geometry set is disjoint "
            "from this replay's primary 88–95 panel. No new neural forward or fitted policy.",
        },
    )


if __name__ == "__main__":
    main()
