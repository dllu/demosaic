"""Apply the calibrated exterior phase diagnostic to a frozen reconstruction."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from exterior import ARMS, nominated
from quadrature import ROOT, rgb_residual, subtract, witnesses
from shrinkage import _unit
from mixture import PRIOR, combine
from evaluate_shrinkage import load
import evaluate_shrinkage as original
import evaluate_gap_head as review
from review_quiet import LOCAL, numeric
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

CAPTIONS = {
    'Bayer-gated': 'Bayer-gated refit',
    'ring8': 'Eight-donor EMA',
    'exterior-phase-locked': 'Exterior amplitude',
    'exterior-local': 'Exterior phase, local veto',
    'exterior-only': 'Exterior phase',
}


def setup():
    torch.set_num_threads(1)
    models, previous, prior = load(raw_weights=False)
    pointer = reference(ROOT / 'exterior-screen.json')
    screen = read_json(checked(pointer))
    assert prior['wide_training'] == screen['ring8_training']
    assert prior['wide_checkpoint'] == screen['ring8_checkpoint']
    assert prior['parent'] == screen['parent']
    doses = {name: screen['calibration'][name]['gain'] for name in ARMS}
    return (models[0], models[1], doses), {
        'driver': reference(__file__), 'calibration': pointer, 'wide_training': screen['ring8_training'],
        'checkpoint': screen['ring8_checkpoint'], 'parent': screen['parent'],
        'frozen_phase': prior['frozen_phase_checkpoint'], 'doses': doses,
        'prior_frozen_controls': previous,
    }


@torch.inference_mode()
def render_models(raw, layout, wb, matrix, noise, box, exterior, parent, models, _unused=None):
    reconstruction, networks, doses = models
    donors = review.exterior(exterior, layout, noise, box)
    field, _, near, wide, _, _, baseline = witnesses(raw, layout, noise, box, donors, parent, wb, matrix, reconstruction)
    *_, frozen, experts, descriptors, _ = baseline
    restored = parent + rgb_residual(wide, field)
    phase = _unit(np.where(abs(wide) > 1e-8, wide, near))
    seen, predicted, sigma = subtract(raw, layout, noise, restored)
    extra = nominated(raw, layout, noise, phase, seen, predicted, sigma)
    control = combine(networks, field, frozen, experts, descriptors)['Bayer-gated']
    values = {'ring8': restored, 'Bayer-gated': parent + control}
    for name in ARMS:
        values[name] = restored + np.float32(doses[name]) * rgb_residual(extra[name], field)
    assert all(v.dtype == np.float32 and np.isfinite(v).all() for v in values.values())
    return {key: values[key] for key in CAPTIONS}


def predict(native, surround, noise, box, parents, models, _unused=True):
    outputs = {}
    for raw, layout, wb, matrix, parent in zip(native['packed'], native['colors'], native['wb'],
                                              native['matrix'], parents[LOCAL], strict=True):
        for key, value in render_models(raw, layout, wb, matrix, noise, box, surround, parent, models).items():
            outputs.setdefault(key, []).append(value)
    return {key: np.stack(seq) for key, seq in outputs.items()}


def natural(models, receipt):
    start = time.monotonic()
    old = reference(ROOT.parent / 'bayer-phase-shrinkage-v1' / 'photo-holdout.json')
    previous = {r['id']: r for r in read_json(checked(old))['rows']}
    samples = read_json(checked(reference(PRIOR / 'natural-results.json')))
    records = read_json(checked(samples['inputs']))['records']
    distinct = review.panel_membership()
    sources = []
    for record in records:
        case = read_json(checked(read_json(checked(record))['case']))
        if case['draw'] == 'independent' and case['source'] not in distinct:
            sources.append(record)
    assert len(sources) == 96
    original.predict = predict
    rows = review.run(sources, partial(original.photo_row, models=models, scales={}))
    for row in rows:
        old_row = previous[row['id']]
        assert old_row['input'] == row['input'] and old_row['local20k_outputs'] == row['local20k_outputs']
        for key in ('increment_rms', 'flat_rms', 'intact_dot', 'intact_power'):
            a, b = (r['metrics']['ring8'][key] for r in (row, old_row))
            assert abs(a-b) < .001, (key, a, b)
    groups = {p: [r for r in rows if r['profile'] == p] for p in ('iso400', 'iso6400')}
    metrics = ('intact_response', 'increment_rms', 'flat_rms', 'srgb_present_psnr')
    labels = [(a, b) for a in ARMS for b in ('ring8', 'V120', '100k')]
    write_json(ROOT / 'natural-screen.json', receipt | {'prior': old, 'rows': rows,
               'reports': numeric(groups, labels, metrics), 'wall_seconds': time.monotonic() - start})


if __name__ == '__main__':
    assert sys.argv[1] == 'natural'
    natural(*setup())
