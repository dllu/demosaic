"""Bind the diagnostic receipts to the exact executed programs and inputs."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results') / ROOT.name
IMAGES = Path('docs/images') / ROOT.name


def publish_board(record, scope):
    source = checked(record['image'])
    destination = IMAGES / scope / source.name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert reference(destination)['sha256'] == record['image']['sha256']
    record['image']['path'] = destination.relative_to(IMAGES).as_posix()
    panels = {}
    with Image.open(destination) as image:
        for entry in record['panels']:
            x, y, w, h = entry['png_xywh']
            assert w == h == 160 and 0 <= x <= image.width - w and 0 <= y <= image.height - h
            panels[entry.get('label') or entry['name']] = image.crop((x, y, x+w, y+h))
    assert len(panels) == len(record['panels'])
    return panels


def publish_images(screen):
    review = {}
    for scope, count in (('standing', 8), ('exact', 3)):
        manifest = read_json(ROOT / scope / 'manifest.json')
        assert len(manifest['rows']) == count and manifest['calibration'] == screen
        checked(manifest['driver'])
        for row in manifest['rows']:
            panels = publish_board(row['board'], scope)
            if scope == 'exact':
                for triplet in (row['triplet'], *row['other_triplets'].values()):
                    crops = publish_board(triplet, scope)
                    for name, crop in crops.items():
                        assert ImageChops.difference(crop, panels[name]).getbbox() is None
        review[scope] = manifest
    review['native_viewing'] = {'standing_boards': 8, 'exact_boards': 3,
        'findings': 'Sky remains smooth. Fine cables and leaf detail remain soft. Coarse links remain visible. The fine left and right cab crossings are incomplete with mottling under both profiles.'}
    path = IMAGES / 'manifest.json'
    write_json(path, review)
    return {'path': f'../../images/{ROOT.name}/manifest.json', 'sha256': reference(path)['sha256']}


def main():
    OUT.mkdir(exist_ok=True)
    archive_name = OUT / 'evidence.tar.xz'
    files = {p: ROOT / p for p in (
        'wire-screen.json', 'wire-screen-final.log', 'wire-screen.log', 'exterior-screen.json',
        'exterior-screen.log', 'tests.log', 'quadrature.py', 'exterior.py', 'publish.py',
        'composed.py', 'render_exterior.py', 'natural-screen.json', 'natural-screen.log',
        'standing/manifest.json', 'standing.log', 'exact/manifest.json', 'exact.log',
    )}
    files['original/quadrature.py'] = ROOT / 'local_executed.py'
    programs = {'wire-screen': files['original/quadrature.py'], 'exterior-screen': files['exterior.py']}
    prior = reference(ROOT.parent / 'bayer-phase-shrinkage-v1' / 'wire-holdout.json')
    files['upstream/prior-wire-holdout.json'] = checked(prior)
    results = {}
    for name, program in programs.items():
        receipt = read_json(files[f'{name}.json'])
        assert reference(program)['sha256'] == receipt['driver']['sha256']
        if 'protocol' in receipt:
            checked(receipt['protocol'])
        for k in ('ring8_training', 'ring8_checkpoint', 'parent'):
            checked(receipt[k])
        for scope, expected in (('wire-tune', 24), ('wire', 48)):
            summary = checked(receipt['sources'][scope])
            assert len(receipt['rows'][scope]) == expected
            files[f'upstream/{summary.name}'] = summary
            for row in receipt['rows'][scope]:
                checked(row['input'])
                checked(row['local20k_output'])
        results[name] = {k: receipt[k] for k in ('ring8_training', 'ring8_checkpoint', 'parent',
                                                'sources', 'calibration', 'heldout', 'wall_seconds')}
    assert all(results['wire-screen'][k] == results['exterior-screen'][k]
               for k in ('ring8_training', 'ring8_checkpoint', 'parent', 'sources'))
    calibration = reference(ROOT / 'exterior-screen.json')
    natural = read_json(files['natural-screen.json'])
    assert natural['calibration'] == calibration and len(natural['rows']) == 96
    for row in natural['rows']:
        checked(row['input'])
        checked(row['local20k_outputs'])
    image_manifest = publish_images(calibration)
    with tarfile.open(archive_name, 'x:xz') as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name, recursive=False)
    with tarfile.open(archive_name) as archive:
        assert archive.getnames() == sorted(files)
        for name, path in files.items():
            with archive.extractfile(name) as contents:
                assert contents.read() == path.read_bytes()
    write_json(OUT / 'publication.json', {
        'archive': {'path': 'evidence.tar.xz', 'sha256': reference(archive_name)['sha256'],
                    'entries': len(files)},
        'prior': prior, 'results': results,
        'natural_photos': {'reports': natural['reports'], 'wall_seconds': natural['wall_seconds'],
                           'source_count': 48, 'draws': 'independent'},
        'scope': 'Constructed wire phase diagnostic. Frozen inference checkpoints and scalar calibration only.',
        'new_checkpoint': None, 'native_review': image_manifest, 'broad_evaluation': None,
    })


if __name__ == '__main__':
    main()
