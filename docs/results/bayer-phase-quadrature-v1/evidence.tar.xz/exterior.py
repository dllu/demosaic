"""Fit independent exterior carriers and measure their phase on held-out neighbors."""
from functools import partial

import numpy as np

from quadrature import recover, run
from wide_witness import CORNERS, NEAR, choose, contributions
from demosaic.phase_witness import MEAN_RESPONSE, _gather, _transform, _unit

ARMS = ('exterior-only', 'exterior-local', 'exterior-phase-locked')


def nominated(raw, layout, noise, phase, seen, predicted, sigma):
    transform, variance = _transform(raw, float(noise['shot']), float(noise['read']))
    greens = np.flatnonzero(layout == 1)
    direct = sum(_gather(transform, p) for p in greens) * .5
    green_variance = variance[:, greens].sum(1) * .25
    cardinal, diagonal = (contributions(direct, green_variance, geometry) for geometry in (NEAR, CORNERS))
    gains = []
    gates = []
    for donor, reserved, geometry in ((cardinal, diagonal, CORNERS), (diagonal, cardinal, NEAR)):
        values, power = donor
        held, held_power = reserved
        offset, selected = choose(values, power, True)
        _unused, counts = contributions(direct, np.ones_like(green_variance), geometry)
        sample = lambda a: np.take_along_axis(a, selected, axis=1)
        witness = sample(held)
        expected = _unit(sample(values))
        hold_z = (witness * expected.conj()).real / np.sqrt(sample(held_power)).clip(min=2e-5)
        gain = witness * MEAN_RESPONSE[offset] / sample(counts).clip(min=1)
        # This amplitude uses reserved windows only, without averaging in the
        # data that selected its frequency. The split estimates swap roles.
        gains.append(gain)
        strength = np.maximum(hold_z - 1, 0)
        gates.append(strength / (1 + strength))
    gate = np.sqrt(gates[0] * gates[1]) * (gains[0] * gains[1].conj()).real.clip(min=0) / (
        abs(gains[0]) * abs(gains[1])).clip(min=1e-12)
    query = seen.mean(axis=0)
    innovation = ((gains[0] + gains[1]) * .5 - predicted.mean(axis=0)) * phase.conj()
    query_deficit = ((query - predicted.mean(axis=0)) * phase.conj()).imag
    # The native query can veto an exterior angular change where the local
    # green residual points the other way. It never nominates the frequency.
    local_gate = (query_deficit * innovation.imag > 0)
    limit = 2 * sigma.mean(0)
    return {
        'exterior-only': 1j * phase * gate * innovation.imag.clip(-limit, limit),
        'exterior-local': 1j * phase * gate * local_gate * innovation.imag.clip(-limit, limit),
        'exterior-phase-locked': phase * gate * innovation.real.clip(-limit, limit),
    }


if __name__ == '__main__':
    run(True, estimator=partial(recover, extra=nominated), methods=ARMS, driver=__file__, stem='exterior-screen')
