"""Screen for independently supported rotation of a frozen Bayer residual."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'bayer-phase-shrinkage-v1'))
from shrinkage import witnesses, rgb_residual
from train_shrinkage import frozen
from mixture import PRIOR
from head_corrected_broad import direct_fft, green_units
from review_quiet import CORE, LOCAL, numeric, wire_inputs
import evaluate_gap_head as review

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.phase_witness import BASE, XI, YI, _gather, _transform, _unit

INNER = (2 * XI >= 64) & (2 * XI + 32 <= 192) & (2 * YI >= 64) & (2 * YI + 32 <= 192)
MODES = ('green-mean', 'green-agreement', 'phase-locked')
METRICS = ('intact_response', 'intact_rms', 'gap_exact', 'flat_rms', 'flat_change')


def subtract(raw, layout, noise, restored):
    """Measure RAW and parent on the same green sites, FFT grid and taper."""
    shot, read = (float(noise[key]) for key in ('shot', 'read'))
    transform, variance = _transform(raw, shot, read)
    packed = np.stack([restored[1, p // 2::2, p % 2::2] for p in range(4)])
    predicted, _ = _transform(packed, shot, read)
    g = np.flatnonzero(layout == 1)
    slots = np.broadcast_to(BASE, (len(XI), len(BASE)))
    seen = np.stack([_gather(transform, p, slots) for p in g])
    parents = np.stack([_gather(predicted, p, slots) for p in g])
    sigma = np.sqrt(variance[:, g].T)[:, :, None].clip(min=2e-5)
    return seen, parents, sigma


@torch.inference_mode()
def recover(raw, layout, noise, box, donors, parent, wb, matrix, target, networks, extra=None):
    field, _, nearest, wide, _, descriptors, _ = witnesses(
        raw, layout, noise, box, donors, parent, wb, matrix, networks,
    )
    restored = parent + rgb_residual(wide, field)
    phase = _unit(np.where(abs(wide) > 1e-8, wide, nearest))
    seen, predicted, sigma = subtract(raw, layout, noise, restored)
    deficit = (seen - predicted) * phase.conj()
    phase_cross = ((seen[0] * seen[1].conj()).real / (sigma[0] * sigma[1])).clip(min=0)
    supported = (abs(phase) > .5) * (phase_cross / (1 + phase_cross))
    # The same residual is measured on both Bayer greens. Agreement is on
    # the raw quadrature sign before subtracting a shared parent estimate.
    q = (seen * phase.conj()).imag
    agree = np.where(q[0] * q[1] > 0, np.min(abs(q) / sigma, axis=0), 0)
    gate = supported * (agree / (1 + agree))
    residual = deficit.mean(0)
    limit = 2 * sigma.mean(0)
    q_axis = 1j * phase
    bases = {
        'green-mean': q_axis * supported * residual.imag.clip(-limit, limit),
        'green-agreement': q_axis * gate * residual.imag.clip(-limit, limit),
        'phase-locked': phase * gate * residual.real.clip(-limit, limit),
    }
    if extra is not None:
        bases.update(extra(raw, layout, noise, phase, seen, predicted, sigma))
    out = {label: rgb_residual(coefficient, field) for label, coefficient in bases.items()}
    exact = direct_fft(green_units(target, wb, matrix, field.neutral))
    remain = exact - direct_fft(green_units(restored, wb, matrix, field.neutral))
    rotated = remain * phase.conj()
    orthogonal = q_axis * rotated.imag
    parallel = phase * rotated.real
    for name, coefficient in bases.items():
        direction = phase if name.endswith('phase-locked') else q_axis
        assert np.max(abs((coefficient * direction.conj()).imag)) < 1e-7
    out['oracle-quadrature'] = rgb_residual(orthogonal, field)
    out['oracle-phase'] = rgb_residual(parallel, field)
    # These are exact-target probes. Inference candidates do not access them.
    joint_donor_snr = np.expm1(np.minimum(descriptors[..., 4], descriptors[..., 5]))
    return restored, out, (rotated.real, rotated.imag, abs(phase) > .5), joint_donor_snr


def products(target, signal):
    target, signal = (a.astype(np.float64, copy=False).ravel() for a in (target, signal))
    return [float(target @ target), float(target @ signal), float(signal @ signal), len(target)]


def observe(task, networks, plan, lookup, estimator=recover):
    data, parents, proof = wire_inputs(task, lookup, None)
    scene = plan['sources'][task['index']]
    noise = plan['profiles'][task['noise']]
    donations = review.exterior(data['full'], data['colors'][0], noise, plan['query'])
    roles = [estimator(raw, layout, noise, plan['query'], donations, parent, wb, matrix, exact, networks)
             for raw, layout, parent, wb, matrix, exact in zip(
                 data['packed'], data['colors'], parents[LOCAL], data['wb'], data['matrix'], data['target'], strict=True,
             )]
    baseline = np.stack([r[0] for r in roles])
    luma = lambda rgb: review.old.luma(rgb, data)[..., CORE[0], CORE[1]]
    clean, base = luma(data['target']), luma(baseline)
    support = data['support'][CORE]
    intact, gap = support >= .97, support <= .01
    error = base - clean
    target = (clean[0] - clean[1])[intact]
    powered = {}
    for name in roles[0][1]:
        correction = luma(np.stack([r[1][name] for r in roles]))
        increment = (correction[0] - correction[1])[intact]
        powered[name] = {
            'intact_rms': products((error[0]-error[1])[intact], increment),
            'intact': [*review.aligned(target, (base[0]-base[1])[intact]), *review.aligned(target, increment)],
            'gap_exact': products(error[0][gap], correction[0][gap]),
            'flat_rms': products(error[3, 8:-8, 8:-8], correction[3, 8:-8, 8:-8]),
        }
    re, im, available = roles[0][2]
    strong = available & INNER[:, None] & (roles[0][3] >= 3)
    audit = {name: products(re[m], im[m]) for name, m in
             (('all', available & INNER[:, None]), ('both-donor-groups-SNR-at-least-3', strong))}
    return {'id': f'{task["index"]:03d}-{task["noise"]}', 'source_id': scene['source']['id'],
            'profile': task['noise'], 'input': task['input'], 'local20k_output': proof,
            'gap_pixels': int(gap.sum()), 'products': powered, 'coefficient_error': audit}


def rms_at(gram, dose):
    xx, xy, yy, n = gram
    return float(65535 * np.sqrt(max(0, xx + 2 * dose * xy + dose**2 * yy) / n)) if n else None


def scores(row, modes):
    metrics = {}
    for label, name, dose in modes:
        data = row['products'][name]
        dot, power, extra, _ = data['intact']
        metrics[label] = {key: rms_at(data[key], dose) for key in ('intact_rms', 'gap_exact', 'flat_rms')}
        metrics[label].update(intact_dot=dot+dose*extra, intact_power=power,
                              flat_change=rms_at([0, 0, *data['flat_rms'][2:]], dose))
    return row | {'metrics': metrics | {'matched': metrics['ring8']}}


def calibrate(rows, methods):
    """Choose dosage on calibration backgrounds with fixed maximum RMS increases."""
    assert len(rows) == 24 and {row['profile'] for row in rows} == {'iso6400'}
    result = {}
    for mode in methods:
        gaps = [row['products'][mode]['gap_exact'] for row in rows if row['gap_pixels']]
        flats = [row['products'][mode]['flat_rms'] for row in rows]
        intact = [row['products'][mode]['intact_rms'] for row in rows]
        assert len(gaps) == 12
        options = []
        for gain in np.linspace(0, 1, 101):
            changes = [float(np.mean([rms_at(x, gain) - rms_at(x, 0) for x in group]))
                       for group in (intact, gaps, flats)]
            if changes[1] <= .02 and changes[2] <= .02:
                options.append((changes[0], float(gain), changes[1], changes[2]))
        best = min(options)
        result[mode] = dict(zip(('intact_change', 'gain', 'gap_change', 'flat_change'), best, strict=True))
    return result


def cohort(rows, profile):
    return [row for row in rows if row['profile'] == profile]


def run(load_holdout, *, estimator=recover, methods=MODES, driver=__file__, stem='wire-screen'):
    tick = time.monotonic()
    torch.set_num_threads(1)
    models, binding, recipe = frozen()
    sources = {}
    rows = {}
    for scope in ('wire-tune', 'wire') if load_holdout else ('wire-tune',):
        sources[scope] = reference(PRIOR / f'{scope}-parent.json')
        observed = read_json(checked(sources[scope]))
        plan = read_json(checked(observed['plan']))
        lookup = {row['id']: row for row in observed['rows']}
        records = read_json(checked(observed['inputs']))['rows']
        rows[scope] = review.run(records, partial(observe, networks=models, plan=plan, lookup=lookup, estimator=estimator))
    train = rows['wire-tune']
    assert len(train) == 24
    profiles = ('iso400', 'iso6400')
    choices = calibrate(train, methods)
    output = {'driver': reference(driver), 'protocol': reference(__file__), 'ring8_training': binding, 'ring8_checkpoint': recipe['checkpoint'],
              'parent': recipe['parent'], 'sources': sources, 'calibration': choices, 'rows': rows}
    if load_holdout:
        held = rows['wire']
        assert len(held) == 48 and {r['source_id'] for r in held}.isdisjoint(r['source_id'] for r in train)
        old = read_json(checked(reference(ROOT.parent / 'bayer-phase-shrinkage-v1/wire-holdout.json')))
        previous = {row['id']: row for row in old['rows']}
        groups = {}
        for p in profiles:
            modes = [('ring8', methods[0], 0)]
            for name in methods:
                modes += [(name, name, choices[name]['gain']), (name + '-10pct', name, .10)]
            modes += [(name, name, .25) for name in ('oracle-phase', 'oracle-quadrature')]
            groups[p] = [scores(row, modes) for row in cohort(held, p)]
            for row in groups[p]:
                earlier = previous[row['id']]
                assert row['input'] == earlier['input'] and row['local20k_output'] == earlier['local20k_output']
                for key in ('intact_rms', 'gap_exact'):
                    before, after = (earlier['metrics']['ring8'][key], row['metrics']['ring8'][key])
                    if before is not None:
                        assert abs(before - after) < .001, (before, after)
        output['heldout'] = numeric(groups, [(key, 'ring8') for key in groups['iso6400'][0]['metrics']
                                    if key not in ('ring8', 'matched')], METRICS)
    output['wall_seconds'] = time.monotonic() - tick
    write_json(ROOT / f'{stem}.json', output)
    print(choices, flush=True)


if __name__ == '__main__':
    run(sys.argv[1] == 'both')
